import React, { useState, useEffect } from 'react';
import { Target, Award, Home, Users, TrendingUp, X, Crown, Lock, Sparkles, Zap, ChevronRight, Calculator, FileText, TrendingDown, DollarSign, PieChart, BarChart3, Activity, Shield, Briefcase, Gift, Plane } from 'lucide-react';

const LifeVest = () => {
  const [activeTab, setActiveTab] = useState('home');
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [currentTier, setCurrentTier] = useState('free'); // 'free', 'voyager', 'sovereign', 'platinum'
  const [selectedTier, setSelectedTier] = useState('sovereign');
  const [billingCycle, setBillingCycle] = useState('annual'); // 'monthly' or 'annual'
  const [showPaywall, setShowPaywall] = useState(false);
  const [showToolModal, setShowToolModal] = useState(false);
  const [selectedTool, setSelectedTool] = useState(null);
  const [dailyStreak] = useState(7);
  const [barnaclePoints] = useState(1250);
  const [knowledgeXP] = useState(350);

  // Sound System
  const playSound = (type) => {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      
      const configs = {
        wave: { freq: 200, decay: 0.5, vol: 0.1 },
        bubble: { freq: 800, decay: 0.1, vol: 0.15 },
        success: { freq: 523.25, decay: 0.3, vol: 0.2 },
        unlock: { freq: 1000, decay: 0.3, vol: 0.15 }
      };
      
      const config = configs[type] || configs.bubble;
      osc.frequency.setValueAtTime(config.freq, ctx.currentTime);
      gain.gain.setValueAtTime(config.vol, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + config.decay);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + config.decay);
    } catch(e) {}
  };

  const navigateTo = (tab) => {
    if (tab === activeTab) return;
    playSound('wave');
    setIsTransitioning(true);
    requestAnimationFrame(() => {
      setTimeout(() => {
        setActiveTab(tab);
        requestAnimationFrame(() => {
          setIsTransitioning(false);
        });
      }, 350);
    });
  };

  const subscriptionTiers = {
    voyager: {
      name: 'Voyager',
      icon: '⚓',
      color: '#00d4ff',
      tagline: 'Start Your Journey',
      price: { monthly: 9, annual: 89 },
      savings: 19,
      features: [
        { icon: '🤖', name: 'Autopilot Investing Lite', desc: 'Monthly rebalancing + round-ups' },
        { icon: '🎓', name: '10 Premium Courses', desc: 'Core financial literacy' },
        { icon: '📊', name: 'Basic Analytics', desc: 'Portfolio health score' },
        { icon: '👥', name: 'Community Access', desc: 'Join The Reef' },
        { icon: '📈', name: '3 Investment Strategies', desc: 'Copy proven strategies' },
        { icon: '📰', name: 'Monthly Insights', desc: 'Curated market news' },
        { icon: '💳', name: 'Debt Calculator', desc: 'Snowball & avalanche tools' }
      ],
      limits: { strategies: 3, courses: 10, sessions: 0, family: 1 }
    },
    sovereign: {
      name: 'Sovereign',
      icon: '👑',
      color: '#ffd700',
      tagline: 'Master Your Wealth',
      badge: 'BEST VALUE',
      price: { monthly: 29, annual: 299 },
      savings: 49,
      features: [
        { icon: '✨', name: 'Everything in Voyager', header: true },
        { icon: '🤖', name: 'AI Financial Coach', desc: 'Daily insights + voice chat', premium: true },
        { icon: '💰', name: 'Tax-Loss Harvesting', desc: 'Save $500-2K/year', premium: true },
        { icon: '🔬', name: 'Portfolio X-Ray', desc: 'Advanced analytics', premium: true },
        { icon: '🔮', name: 'Retirement Crystal Ball', desc: 'Monte Carlo simulations', premium: true },
        { icon: '🎓', name: '50+ Premium Courses', desc: 'Full academy access', premium: true },
        { icon: '🐋', name: 'Whale Alerts', desc: 'Follow insider trades', premium: true },
        { icon: '📊', name: '20 Strategies', desc: 'Copy top performers', premium: true },
        { icon: '🧮', name: '12 Advanced Calculators', desc: 'Full tool suite', premium: true },
        { icon: '👨‍💼', name: '1 Expert Session/Year', desc: '30-min CFP call', premium: true },
        { icon: '⚡', name: 'Priority Support', desc: '24-hour response', premium: true },
        { icon: '🗄️', name: 'Document Vault', desc: '5GB secure storage', premium: true }
      ],
      limits: { strategies: 20, courses: 50, sessions: 1, family: 1 }
    },
    platinum: {
      name: 'Platinum',
      icon: '💎',
      color: '#c0c0c0',
      tagline: 'Ultimate Command',
      badge: 'PREMIUM',
      price: { monthly: 79, annual: 799 },
      savings: 149,
      features: [
        { icon: '✨', name: 'Everything in Sovereign', header: true },
        { icon: '🎯', name: 'Account Manager', desc: 'Personal CFP concierge', premium: true },
        { icon: '♾️', name: 'Unlimited Strategies', desc: 'All 100+ strategies', premium: true },
        { icon: '👨‍👩‍👧‍👦', name: 'Family Plan', desc: '4 members ($19.75 each)', premium: true },
        { icon: '🌙', name: 'After-Hours Trading', desc: '7am-8pm EST', premium: true },
        { icon: '💳', name: 'Metal Card', desc: '3% cash back', premium: true },
        { icon: '📞', name: 'Quarterly Calls', desc: '4 sessions/year', premium: true },
        { icon: '🎨', name: 'Custom Portfolio', desc: 'Tailored design', premium: true },
        { icon: '📋', name: 'Tax Session', desc: 'Annual optimization', premium: true },
        { icon: '💬', name: 'Bill Negotiation', desc: 'Avg $720/year saved', premium: true },
        { icon: '✈️', name: 'Airport Lounges', desc: '4 visits/year', premium: true },
        { icon: '🏰', name: 'Platinum Pods', desc: 'HNW network', premium: true },
        { icon: '🚀', name: 'Early Access', desc: 'Beta features', premium: true },
        { icon: '🎪', name: 'Conference VIP', desc: 'Free ticket + dinner', premium: true }
      ],
      limits: { strategies: 999, courses: 999, sessions: 4, family: 4 }
    }
  };

  const premiumTools = [
    {
      id: 'compound',
      name: 'Compound Interest Calculator',
      icon: '📈',
      category: 'Planning',
      tier: 'voyager',
      description: 'Project portfolio growth over time',
      inputs: ['principal', 'rate', 'time', 'contribution']
    },
    {
      id: 'retirement',
      name: 'Retirement Planner',
      icon: '🏝️',
      category: 'Planning',
      tier: 'sovereign',
      description: 'Calculate exact retirement needs',
      inputs: ['age', 'retireAge', 'lifeExpectancy', 'savings']
    },
    {
      id: 'taxOptimizer',
      name: 'Tax Optimizer',
      icon: '📋',
      category: 'Tax',
      tier: 'sovereign',
      description: 'Minimize tax burden with smart strategies',
      inputs: ['income', 'deductions', 'filingStatus']
    },
    {
      id: 'assetAllocation',
      name: 'Asset Allocation Builder',
      icon: '🎯',
      category: 'Investment',
      tier: 'sovereign',
      description: 'Optimize portfolio by risk tolerance',
      inputs: ['age', 'riskTolerance', 'timeHorizon']
    },
    {
      id: 'dividend',
      name: 'Dividend Tracker',
      icon: '💰',
      category: 'Investment',
      tier: 'sovereign',
      description: 'Track dividend income and reinvestment',
      inputs: ['stocks', 'shares', 'dividendYield']
    },
    {
      id: 'homeAfford',
      name: 'Home Affordability',
      icon: '🏠',
      category: 'Planning',
      tier: 'sovereign',
      description: 'Calculate max home price you can afford',
      inputs: ['income', 'debts', 'downPayment', 'rate']
    },
    {
      id: 'college529',
      name: 'College Savings (529)',
      icon: '🎓',
      category: 'Planning',
      tier: 'sovereign',
      description: 'Plan for education expenses',
      inputs: ['yearsUntilCollege', 'costPerYear', 'currentSavings']
    },
    {
      id: 'fire',
      name: 'FIRE Calculator',
      icon: '🔥',
      category: 'Planning',
      tier: 'sovereign',
      description: 'Calculate early retirement timeline',
      inputs: ['expenses', 'savings', 'savingsRate']
    },
    {
      id: 'netWorth',
      name: 'Net Worth Projector',
      icon: '💎',
      category: 'Planning',
      tier: 'platinum',
      description: 'Project future net worth',
      inputs: ['currentNetWorth', 'savingsRate', 'returnRate']
    },
    {
      id: 'estate',
      name: 'Estate Planning',
      icon: '🏛️',
      category: 'Tax',
      tier: 'platinum',
      description: 'Plan estate and inheritance taxes',
      inputs: ['estateValue', 'heirs', 'gifting']
    },
    {
      id: 'mortgageRent',
      name: 'Mortgage vs Rent',
      icon: '🏘️',
      category: 'Planning',
      tier: 'sovereign',
      description: 'Compare buying vs renting costs',
      inputs: ['homePrice', 'rent', 'downPayment', 'rate']
    },
    {
      id: 'crypto',
      name: 'Crypto Portfolio Tracker',
      icon: '₿',
      category: 'Investment',
      tier: 'platinum',
      description: 'Track cryptocurrency holdings',
      inputs: ['coins', 'amounts', 'costBasis']
    }
  ];

  const handleToolClick = (tool) => {
    playSound('bubble');
    const tierOrder = ['free', 'voyager', 'sovereign', 'platinum'];
    const userTierIndex = tierOrder.indexOf(currentTier);
    const toolTierIndex = tierOrder.indexOf(tool.tier);
    
    if (userTierIndex < toolTierIndex) {
      setShowPaywall(true);
    } else {
      setSelectedTool(tool);
      setShowToolModal(true);
    }
  };

  const handleSubscribe = () => {
    playSound('unlock');
    setTimeout(() => playSound('success'), 300);
    setCurrentTier(selectedTier);
    setShowPaywall(false);
  };

  const getTierPrice = (tier) => {
    const plan = subscriptionTiers[tier];
    if (!plan) return 0;
    return billingCycle === 'annual' ? plan.price.annual : plan.price.monthly;
  };

  const PaywallModal = () => (
    <div className="modal-overlay" onClick={() => setShowPaywall(false)}>
      <div className="paywall-modal" onClick={e => e.stopPropagation()}>
        <button className="modal-close" onClick={() => setShowPaywall(false)}>
          <X size={24} />
        </button>

        <div className="paywall-header">
          <Crown className="paywall-icon" size={56} />
          <h2 className="paywall-title">Unlock Your Financial Future</h2>
          <p className="paywall-subtitle">Choose the plan that fits your goals</p>
        </div>

        <div className="billing-toggle">
          <button 
            className={`toggle-btn ${billingCycle === 'monthly' ? 'active' : ''}`}
            onClick={() => setBillingCycle('monthly')}
          >
            Monthly
          </button>
          <button 
            className={`toggle-btn ${billingCycle === 'annual' ? 'active' : ''}`}
            onClick={() => setBillingCycle('annual')}
          >
            Annual <span className="save-badge">Save up to $149</span>
          </button>
        </div>

        <div className="tiers-grid">
          {Object.entries(subscriptionTiers).map(([key, tier]) => (
            <div 
              key={key}
              className={`tier-card ${selectedTier === key ? 'selected' : ''}`}
              onClick={() => {
                playSound('bubble');
                setSelectedTier(key);
              }}
            >
              {tier.badge && <div className="tier-badge">{tier.badge}</div>}
              <div className="tier-icon" style={{fontSize: '48px'}}>{tier.icon}</div>
              <h3 className="tier-name">{tier.name}</h3>
              <p className="tier-tagline">{tier.tagline}</p>
              
              <div className="tier-price">
                <span className="price-amount">${getTierPrice(key)}</span>
                <span className="price-period">/{billingCycle === 'annual' ? 'year' : 'month'}</span>
              </div>
              
              {billingCycle === 'annual' && tier.savings && (
                <div className="tier-savings">Save ${tier.savings}/year</div>
              )}

              <div className="tier-features">
                {tier.features.slice(0, 5).map((feature, i) => (
                  <div key={i} className={`feature-item ${feature.header ? 'header' : ''}`}>
                    {!feature.header && <span className="feature-icon">{feature.icon}</span>}
                    <div className="feature-text">
                      <div className="feature-name">{feature.name}</div>
                      {feature.desc && <div className="feature-desc">{feature.desc}</div>}
                    </div>
                  </div>
                ))}
                <div className="feature-more">+{tier.features.length - 5} more features</div>
              </div>
            </div>
          ))}
        </div>

        <div className="value-calculator">
          <h4>Sovereign Value Calculator</h4>
          <div className="value-breakdown">
            <div className="value-item">
              <span>Tax-Loss Harvesting:</span>
              <span className="value-amount">$1,500/year</span>
            </div>
            <div className="value-item">
              <span>AI Coach (vs $200/hr CFP):</span>
              <span className="value-amount">$2,400/year</span>
            </div>
            <div className="value-item">
              <span>Premium Tools:</span>
              <span className="value-amount">$300/year</span>
            </div>
            <div className="value-item">
              <span>Whale Alerts:</span>
              <span className="value-amount">$800/year</span>
            </div>
            <div className="value-total">
              <span>Total Value:</span>
              <span className="total-amount">$5,000/year</span>
            </div>
            <div className="value-final">
              <span>Your Price:</span>
              <span className="final-price">${subscriptionTiers.sovereign.price.annual}/year</span>
            </div>
            <div className="value-save">You Save: 94%</div>
          </div>
        </div>

        <button className="subscribe-btn" onClick={handleSubscribe}>
          <Sparkles size={20} />
          Start 7-Day Free Trial
        </button>

        <p className="paywall-disclaimer">
          No credit card required • Cancel anytime • 14-day money-back guarantee
        </p>

        <div className="guarantee-badge">
          <Shield size={16} />
          <span>Save $348 in year 1 or get a full refund</span>
        </div>
      </div>
    </div>
  );

  const ToolModal = () => {
    if (!selectedTool) return null;
    
    return (
      <div className="modal-overlay" onClick={() => setShowToolModal(false)}>
        <div className="tool-modal" onClick={e => e.stopPropagation()}>
          <button className="modal-close" onClick={() => setShowToolModal(false)}>
            <X size={24} />
          </button>

          <div className="tool-header">
            <div className="tool-icon-large">{selectedTool.icon}</div>
            <h3 className="tool-title">{selectedTool.name}</h3>
            <p className="tool-description">{selectedTool.description}</p>
          </div>

          <div className="tool-inputs">
            {selectedTool.inputs.map((input, i) => (
              <div key={i} className="input-group">
                <label>{input.replace(/([A-Z])/g, ' $1').trim()}</label>
                <input type="number" placeholder="Enter value" className="tool-input" />
              </div>
            ))}
          </div>

          <button className="calculate-btn" onClick={() => playSound('success')}>
            <Calculator size={20} />
            Calculate
          </button>

          <div className="tool-result">
            <div className="result-placeholder">
              Enter values above to see results
            </div>
          </div>
        </div>
      </div>
    );
  };

  const HomeView = () => (
    <div className={`view-container ${isTransitioning ? 'transitioning' : ''}`}>
      <div className="hero">
        <div className="whale-icon">🐋</div>
        <h1 className="hero-title">Welcome back, Captain</h1>
        <p className="hero-subtitle">Your financial ocean awaits</p>
      </div>

      {currentTier === 'free' && (
        <div className="upgrade-banner" onClick={() => setShowPaywall(true)}>
          <Crown size={28} />
          <div className="banner-content">
            <div className="banner-title">Unlock Premium Features</div>
            <div className="banner-subtitle">Start with Voyager at just $9/month</div>
          </div>
          <ChevronRight size={20} />
        </div>
      )}

      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon">🔥</div>
          <div className="stat-value">{dailyStreak}</div>
          <div className="stat-label">Day Streak</div>
        </div>
        <div className="stat-card">
          <div className="stat-icon">💰</div>
          <div className="stat-value">{barnaclePoints}</div>
          <div className="stat-label">Barnacle Bucks</div>
        </div>
        <div className="stat-card">
          <div className="stat-icon">🎓</div>
          <div className="stat-value">{knowledgeXP}</div>
          <div className="stat-label">Learning XP</div>
        </div>
      </div>

      {currentTier !== 'free' && (
        <div className="current-plan">
          <div className="plan-header">
            <span className="plan-icon">{subscriptionTiers[currentTier]?.icon}</span>
            <span className="plan-name">{subscriptionTiers[currentTier]?.name} Member</span>
          </div>
          <div className="plan-features">
            <div className="plan-stat">
              <BarChart3 size={16} />
              <span>{subscriptionTiers[currentTier]?.limits.strategies} Strategies</span>
            </div>
            <div className="plan-stat">
              <Award size={16} />
              <span>{subscriptionTiers[currentTier]?.limits.courses} Courses</span>
            </div>
            <div className="plan-stat">
              <Users size={16} />
              <span>{subscriptionTiers[currentTier]?.limits.family} {subscriptionTiers[currentTier]?.limits.family > 1 ? 'Members' : 'Member'}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  const ToolsView = () => (
    <div className={`view-container ${isTransitioning ? 'transitioning' : ''}`}>
      <h2 className="page-title">Premium Tools</h2>
      <p className="page-subtitle">Financial calculators & planning tools</p>

      <div className="tools-grid">
        {premiumTools.map(tool => {
          const tierOrder = ['free', 'voyager', 'sovereign', 'platinum'];
          const isLocked = tierOrder.indexOf(currentTier) < tierOrder.indexOf(tool.tier);
          
          return (
            <div 
              key={tool.id}
              className={`tool-card ${isLocked ? 'locked' : ''}`}
              onClick={() => handleToolClick(tool)}
            >
              {isLocked && (
                <div className="lock-badge">
                  <Lock size={12} />
                  <span>{subscriptionTiers[tool.tier]?.name}</span>
                </div>
              )}
              <div className="tool-icon">{tool.icon}</div>
              <div className="tool-name">{tool.name}</div>
              <div className="tool-category">{tool.category}</div>
              <div className="tool-description">{tool.description}</div>
            </div>
          );
        })}
      </div>
    </div>
  );

  return (
    <div className="lifevest-app">
      <style>{\`
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
          font-family: -apple-system, BlinkMacSystemFont, 'Inter', sans-serif;
          -webkit-font-smoothing: antialiased;
        }

        .lifevest-app {
          min-height: 100vh;
          background: linear-gradient(180deg, #001529 0%, #000a14 100%);
          color: #fff;
          padding-bottom: 100px;
          position: relative;
          overflow-x: hidden;
          transform: translateZ(0);
        }

        .view-container {
          padding: 32px 20px;
          max-width: 680px;
          margin: 0 auto;
          transform: translateZ(0);
          will-change: transform, opacity;
          animation: smoothPageIn 0.5s cubic-bezier(0.16, 1, 0.3, 1);
        }

        @keyframes smoothPageIn {
          0% { opacity: 0; transform: translate3d(40px, 0, 0) scale(0.96); }
          100% { opacity: 1; transform: translate3d(0, 0, 0) scale(1); }
        }

        .view-container.transitioning {
          animation: smoothPageOut 0.35s cubic-bezier(0.4, 0, 1, 1);
        }

        @keyframes smoothPageOut {
          0% { opacity: 1; transform: translate3d(0, 0, 0) scale(1); }
          100% { opacity: 0; transform: translate3d(-40px, 0, 0) scale(0.96); }
        }

        .hero {
          text-align: center;
          margin-bottom: 32px;
        }

        .whale-icon {
          font-size: 64px;
          margin-bottom: 16px;
          animation: smoothBob 2.2s ease-in-out infinite;
        }

        @keyframes smoothBob {
          0%, 100% { transform: translate3d(0, 0, 0); }
          50% { transform: translate3d(0, -10px, 0); }
        }

        .hero-title {
          font-size: 42px;
          font-weight: 700;
          background: linear-gradient(135deg, #fff 0%, #00d4ff 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          margin-bottom: 12px;
        }

        .hero-subtitle {
          color: rgba(255, 255, 255, 0.65);
          font-size: 18px;
        }

        .upgrade-banner {
          display: flex;
          align-items: center;
          gap: 16px;
          padding: 20px;
          background: linear-gradient(135deg, rgba(255, 215, 0, 0.15) 0%, rgba(0, 212, 255, 0.1) 100%);
          border: 1px solid rgba(255, 215, 0, 0.3);
          border-radius: 20px;
          margin-bottom: 24px;
          cursor: pointer;
          transition: all 0.3s ease;
        }

        .upgrade-banner:hover {
          transform: translateY(-4px);
          box-shadow: 0 12px 32px rgba(255, 215, 0, 0.2);
        }

        .banner-content {
          flex: 1;
        }

        .banner-title {
          font-weight: 700;
          font-size: 18px;
          color: #ffd700;
          margin-bottom: 4px;
        }

        .banner-subtitle {
          font-size: 14px;
          color: rgba(255, 255, 255, 0.7);
        }

        .stats-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 12px;
          margin-bottom: 24px;
        }

        .stat-card {
          text-align: center;
          padding: 24px 16px;
          background: rgba(255, 255, 255, 0.05);
          border: 0.5px solid rgba(255, 255, 255, 0.1);
          border-radius: 16px;
          transition: all 0.3s ease;
        }

        .stat-card:hover {
          transform: translateY(-4px);
        }

        .stat-icon {
          font-size: 32px;
          margin-bottom: 12px;
        }

        .stat-value {
          font-size: 28px;
          font-weight: 700;
          margin-bottom: 6px;
        }

        .stat-label {
          font-size: 12px;
          color: rgba(255, 255, 255, 0.5);
          text-transform: uppercase;
        }

        .current-plan {
          background: rgba(0, 212, 255, 0.1);
          border: 1px solid rgba(0, 212, 255, 0.3);
          border-radius: 20px;
          padding: 24px;
          margin-bottom: 24px;
        }

        .plan-header {
          display: flex;
          align-items: center;
          gap: 12px;
          margin-bottom: 16px;
        }

        .plan-icon {
          font-size: 32px;
        }

        .plan-name {
          font-size: 20px;
          font-weight: 700;
          color: #00d4ff;
        }

        .plan-features {
          display: flex;
          gap: 20px;
        }

        .plan-stat {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 14px;
          color: rgba(255, 255, 255, 0.8);
        }

        .page-title {
          font-size: 32px;
          font-weight: 700;
          text-align: center;
          margin-bottom: 8px;
        }

        .page-subtitle {
          text-align: center;
          color: rgba(255, 255, 255, 0.65);
          margin-bottom: 32px;
          font-size: 16px;
        }

        .tools-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 16px;
        }

        .tool-card {
          background: rgba(255, 255, 255, 0.05);
          border: 0.5px solid rgba(255, 255, 255, 0.1);
          border-radius: 20px;
          padding: 24px;
          cursor: pointer;
          transition: all 0.3s ease;
          position: relative;
        }

        .tool-card:hover {
          transform: translateY(-6px);
          box-shadow: 0 12px 32px rgba(0, 0, 0, 0.2);
          border-color: rgba(255, 255, 255, 0.2);
        }

        .tool-card.locked {
          opacity: 0.6;
        }

        .lock-badge {
          position: absolute;
          top: 12px;
          right: 12px;
          background: rgba(255, 215, 0, 0.2);
          border: 1px solid rgba(255, 215, 0, 0.4);
          border-radius: 8px;
          padding: 4px 8px;
          font-size: 10px;
          font-weight: 600;
          color: #ffd700;
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .tool-icon {
          font-size: 40px;
          margin-bottom: 12px;
        }

        .tool-name {
          font-weight: 700;
          font-size: 16px;
          margin-bottom: 6px;
        }

        .tool-category {
          font-size: 11px;
          color: rgba(255, 255, 255, 0.5);
          text-transform: uppercase;
          margin-bottom: 12px;
        }

        .tool-description {
          font-size: 13px;
          color: rgba(255, 255, 255, 0.7);
          line-height: 1.4;
        }

        .modal-overlay {
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.8);
          backdrop-filter: blur(20px);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 3000;
          padding: 24px;
          overflow-y: auto;
          animation: smoothFadeIn 0.25s ease;
        }

        @keyframes smoothFadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }

        .paywall-modal {
          background: rgba(10, 20, 35, 0.95);
          backdrop-filter: blur(80px);
          border: 1px solid rgba(255, 255, 255, 0.15);
          border-radius: 28px;
          padding: 48px 36px;
          max-width: 1100px;
          width: 100%;
          position: relative;
          animation: smoothSlideUp 0.4s cubic-bezier(0.16, 1, 0.3, 1);
        }

        @keyframes smoothSlideUp {
          from { opacity: 0; transform: translate3d(0, 32px, 0) scale(0.95); }
          to { opacity: 1; transform: translate3d(0, 0, 0) scale(1); }
        }

        .modal-close {
          position: absolute;
          top: 20px;
          right: 20px;
          background: rgba(255, 255, 255, 0.1);
          border: none;
          border-radius: 50%;
          width: 40px;
          height: 40px;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          color: #fff;
          transition: all 0.2s ease;
        }

        .modal-close:hover {
          background: rgba(255, 255, 255, 0.2);
          transform: rotate(90deg);
        }

        .paywall-header {
          text-align: center;
          margin-bottom: 32px;
        }

        .paywall-icon {
          color: #ffd700;
          margin-bottom: 16px;
        }

        .paywall-title {
          font-size: 36px;
          font-weight: 700;
          margin-bottom: 12px;
        }

        .paywall-subtitle {
          font-size: 16px;
          color: rgba(255, 255, 255, 0.7);
        }

        .billing-toggle {
          display: flex;
          gap: 8px;
          margin-bottom: 32px;
          background: rgba(255, 255, 255, 0.05);
          padding: 6px;
          border-radius: 12px;
          max-width: 400px;
          margin-left: auto;
          margin-right: auto;
        }

        .toggle-btn {
          flex: 1;
          padding: 12px;
          background: transparent;
          border: none;
          border-radius: 8px;
          color: rgba(255, 255, 255, 0.6);
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .toggle-btn.active {
          background: linear-gradient(135deg, #00d4ff 0%, #40dfff 100%);
          color: #000;
        }

        .save-badge {
          font-size: 11px;
          background: rgba(0, 255, 136, 0.2);
          color: #00ff88;
          padding: 2px 6px;
          border-radius: 4px;
          margin-left: 6px;
        }

        .tiers-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 20px;
          margin-bottom: 32px;
        }

        .tier-card {
          background: rgba(255, 255, 255, 0.04);
          border: 2px solid rgba(255, 255, 255, 0.1);
          border-radius: 24px;
          padding: 28px 24px;
          cursor: pointer;
          transition: all 0.3s ease;
          position: relative;
        }

        .tier-card:hover {
          transform: translateY(-8px);
          box-shadow: 0 16px 48px rgba(0, 0, 0, 0.3);
        }

        .tier-card.selected {
          border-color: #00d4ff;
          background: rgba(0, 212, 255, 0.08);
        }

        .tier-badge {
          position: absolute;
          top: -12px;
          left: 50%;
          transform: translateX(-50%);
          background: #ffd700;
          color: #000;
          padding: 6px 16px;
          border-radius: 12px;
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.05em;
        }

        .tier-icon {
          text-align: center;
          margin-bottom: 12px;
        }

        .tier-name {
          text-align: center;
          font-size: 24px;
          font-weight: 700;
          margin-bottom: 6px;
        }

        .tier-tagline {
          text-align: center;
          font-size: 13px;
          color: rgba(255, 255, 255, 0.6);
          margin-bottom: 20px;
        }

        .tier-price {
          text-align: center;
          margin-bottom: 8px;
        }

        .price-amount {
          font-size: 42px;
          font-weight: 700;
        }

        .price-period {
          font-size: 16px;
          color: rgba(255, 255, 255, 0.6);
        }

        .tier-savings {
          text-align: center;
          font-size: 13px;
          color: #00ff88;
          font-weight: 600;
          margin-bottom: 24px;
        }

        .tier-features {
          border-top: 1px solid rgba(255, 255, 255, 0.1);
          padding-top: 20px;
        }

        .feature-item {
          display: flex;
          gap: 12px;
          margin-bottom: 12px;
          align-items: flex-start;
        }

        .feature-item.header {
          font-weight: 700;
          color: #00d4ff;
          margin-bottom: 16px;
        }

        .feature-icon {
          font-size: 20px;
          flex-shrink: 0;
        }

        .feature-text {
          flex: 1;
        }

        .feature-name {
          font-weight: 600;
          font-size: 14px;
          margin-bottom: 2px;
        }

        .feature-desc {
          font-size: 12px;
          color: rgba(255, 255, 255, 0.6);
        }

        .feature-more {
          text-align: center;
          font-size: 13px;
          color: rgba(255, 255, 255, 0.5);
          margin-top: 16px;
        }

        .value-calculator {
          background: rgba(0, 212, 255, 0.08);
          border: 1px solid rgba(0, 212, 255, 0.3);
          border-radius: 20px;
          padding: 24px;
          margin-bottom: 24px;
        }

        .value-calculator h4 {
          text-align: center;
          margin-bottom: 20px;
          color: #00d4ff;
        }

        .value-breakdown {
          max-width: 400px;
          margin: 0 auto;
        }

        .value-item {
          display: flex;
          justify-content: space-between;
          margin-bottom: 12px;
          font-size: 14px;
        }

        .value-amount {
          color: #00ff88;
          font-weight: 600;
        }

        .value-total {
          display: flex;
          justify-content: space-between;
          padding-top: 12px;
          margin-top: 12px;
          border-top: 1px solid rgba(255, 255, 255, 0.2);
          font-weight: 700;
        }

        .total-amount {
          color: #00d4ff;
          font-size: 18px;
        }

        .value-final {
          display: flex;
          justify-content: space-between;
          margin-top: 8px;
          font-weight: 600;
        }

        .final-price {
          color: #ffd700;
          font-size: 18px;
        }

        .value-save {
          text-align: center;
          margin-top: 16px;
          font-size: 20px;
          font-weight: 700;
          color: #00ff88;
        }

        .subscribe-btn {
          background: linear-gradient(135deg, #00d4ff 0%, #40dfff 100%);
          color: #000;
          border: none;
          border-radius: 14px;
          padding: 18px 36px;
          font-weight: 700;
          font-size: 18px;
          cursor: pointer;
          width: 100%;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 10px;
          transition: all 0.3s ease;
          box-shadow: 0 6px 20px rgba(0, 212, 255, 0.35);
        }

        .subscribe-btn:hover {
          transform: scale(1.02);
          box-shadow: 0 10px 32px rgba(0, 212, 255, 0.5);
        }

        .paywall-disclaimer {
          text-align: center;
          font-size: 13px;
          color: rgba(255, 255, 255, 0.5);
          margin-top: 16px;
        }

        .guarantee-badge {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          margin-top: 16px;
          padding: 12px;
          background: rgba(0, 255, 136, 0.1);
          border: 1px solid rgba(0, 255, 136, 0.3);
          border-radius: 12px;
          color: #00ff88;
          font-size: 14px;
          font-weight: 600;
        }

        .tool-modal {
          background: rgba(10, 20, 35, 0.95);
          backdrop-filter: blur(80px);
          border: 1px solid rgba(255, 255, 255, 0.15);
          border-radius: 28px;
          padding: 36px 32px;
          max-width: 600px;
          width: 100%;
          position: relative;
          animation: smoothSlideUp 0.4s cubic-bezier(0.16, 1, 0.3, 1);
        }

        .tool-header {
          text-align: center;
          margin-bottom: 32px;
        }

        .tool-icon-large {
          font-size: 64px;
          margin-bottom: 16px;
        }

        .tool-title {
          font-size: 28px;
          font-weight: 700;
          margin-bottom: 12px;
        }

        .tool-inputs {
          margin-bottom: 24px;
        }

        .input-group {
          margin-bottom: 16px;
        }

        .input-group label {
          display: block;
          margin-bottom: 8px;
          font-size: 14px;
          font-weight: 600;
          color: rgba(255, 255, 255, 0.8);
          text-transform: capitalize;
        }

        .tool-input {
          width: 100%;
          padding: 12px 16px;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.15);
          border-radius: 12px;
          color: #fff;
          font-size: 16px;
        }

        .tool-input:focus {
          outline: none;
          border-color: #00d4ff;
          background: rgba(255, 255, 255, 0.08);
        }

        .calculate-btn {
          background: linear-gradient(135deg, #00d4ff 0%, #40dfff 100%);
          color: #000;
          border: none;
          border-radius: 12px;
          padding: 14px 28px;
          font-weight: 700;
          font-size: 16px;
          cursor: pointer;
          width: 100%;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 10px;
          transition: all 0.3s ease;
        }

        .calculate-btn:hover {
          transform: scale(1.02);
        }

        .tool-result {
          margin-top: 24px;
          padding: 24px;
          background: rgba(0, 212, 255, 0.08);
          border: 1px solid rgba(0, 212, 255, 0.3);
          border-radius: 16px;
        }

        .result-placeholder {
          text-align: center;
          color: rgba(255, 255, 255, 0.5);
          font-size: 14px;
        }

        .bottom-nav {
          position: fixed;
          bottom: 0;
          left: 0;
          right: 0;
          background: rgba(0, 21, 41, 0.9);
          backdrop-filter: blur(40px);
          border-top: 0.5px solid rgba(255, 255, 255, 0.1);
          padding: 10px 0;
          z-index: 1000;
        }

        .nav-container {
          display: flex;
          justify-content: space-around;
          max-width: 680px;
          margin: 0 auto;
          padding: 0 16px;
        }

        .nav-item {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 4px;
          padding: 8px 14px;
          cursor: pointer;
          border-radius: 12px;
          color: rgba(255, 255, 255, 0.4);
          transition: all 0.2s ease;
        }

        .nav-item:active {
          transform: scale(0.95);
        }

        .nav-item.active {
          color: #00d4ff;
        }

        .nav-label {
          font-size: 11px;
          font-weight: 600;
        }

        @media (max-width: 768px) {
          .tiers-grid {
            grid-template-columns: 1fr;
          }
          
          .tools-grid {
            grid-template-columns: 1fr;
          }
          
          .stats-grid {
            grid-template-columns: 1fr;
          }
        }
      \`}</style>

      {activeTab === 'home' && <HomeView />}
      {activeTab === 'tools' && <ToolsView />}

      {showPaywall && <PaywallModal />}
      {showToolModal && <ToolModal />}

      <div className="bottom-nav">
        <div className="nav-container">
          {[
            { id: 'home', icon: Home, label: 'Home' },
            { id: 'tools', icon: Calculator, label: 'Tools' },
            { id: 'learn', icon: Award, label: 'Learn' },
            { id: 'community', icon: Users, label: 'Community' },
            { id: 'markets', icon: TrendingUp, label: 'Markets' }
          ].map(({ id, icon: Icon, label }) => (
            <div 
              key={id}
              className={\`nav-item \${activeTab === id ? 'active' : ''}\`}
              onClick={() => navigateTo(id)}
            >
              <Icon size={22} />
              <span className="nav-label">{label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default LifeVest;
