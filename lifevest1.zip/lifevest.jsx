import React, { useState, useEffect } from 'react';
import { Flame, Users, Newspaper, Trophy, Home, Target, Zap, Award, ChevronRight, Crown, Lock, Sparkles, TrendingUp, X, ThumbsUp, ThumbsDown, MessageCircle, Send, Play, ExternalLink, Download, FileText, TrendingDown, DollarSign } from 'lucide-react';

const LifeVest = () => {
  const [activeTab, setActiveTab] = useState('home');
  const [dailyStreak, setDailyStreak] = useState(7);
  const [currentGuess, setCurrentGuess] = useState('');
  const [guesses, setGuesses] = useState([]);
  const [gameWon, setGameWon] = useState(false);
  const [barnaclePoints, setBarnaclePoints] = useState(1250);
  const [isPremium, setIsPremium] = useState(false);
  const [knowledgeXP, setKnowledgeXP] = useState(350);
  const [currentQuote, setCurrentQuote] = useState(null);
  const [showQuoteModal, setShowQuoteModal] = useState(false);
  const [showPaywall, setShowPaywall] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState('annual');
  const [currentLesson, setCurrentLesson] = useState(null);
  const [showLessonModal, setShowLessonModal] = useState(false);
  const [lessonProgress, setLessonProgress] = useState({});
  const [showNewPostModal, setShowNewPostModal] = useState(false);
  const [newPostContent, setNewPostContent] = useState('');
  const [reefPosts, setReefPosts] = useState([]);
  const [replyingTo, setReplyingTo] = useState(null);
  const [replyContent, setReplyContent] = useState('');
  const [isTransitioning, setIsTransitioning] = useState(false);
  
  const todaysWord = 'STOCK';

  // ASMR Sound System
  const playSound = (soundType) => {
    try {
      const audioContext = new (window.AudioContext || window.webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      switch(soundType) {
        case 'wave': // Page navigation - gentle ocean wave
          oscillator.type = 'sine';
          oscillator.frequency.setValueAtTime(200, audioContext.currentTime);
          oscillator.frequency.exponentialRampToValueAtTime(100, audioContext.currentTime + 0.5);
          gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
          gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
          oscillator.start(audioContext.currentTime);
          oscillator.stop(audioContext.currentTime + 0.5);
          break;
          
        case 'bubble': // Button clicks
          oscillator.type = 'sine';
          oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
          oscillator.frequency.exponentialRampToValueAtTime(400, audioContext.currentTime + 0.1);
          gainNode.gain.setValueAtTime(0.15, audioContext.currentTime);
          gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);
          oscillator.start(audioContext.currentTime);
          oscillator.stop(audioContext.currentTime + 0.1);
          break;
          
        case 'success': // Goals achieved - 3 note melody
          oscillator.type = 'sine';
          oscillator.frequency.setValueAtTime(523.25, audioContext.currentTime);
          gainNode.gain.setValueAtTime(0.2, audioContext.currentTime);
          gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
          oscillator.start(audioContext.currentTime);
          oscillator.stop(audioContext.currentTime + 0.3);
          
          setTimeout(() => {
            const osc2 = audioContext.createOscillator();
            const gain2 = audioContext.createGain();
            osc2.connect(gain2);
            gain2.connect(audioContext.destination);
            osc2.type = 'sine';
            osc2.frequency.setValueAtTime(659.25, audioContext.currentTime);
            gain2.gain.setValueAtTime(0.2, audioContext.currentTime);
            gain2.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
            osc2.start(audioContext.currentTime);
            osc2.stop(audioContext.currentTime + 0.3);
          }, 150);
          
          setTimeout(() => {
            const osc3 = audioContext.createOscillator();
            const gain3 = audioContext.createGain();
            osc3.connect(gain3);
            gain3.connect(audioContext.destination);
            osc3.type = 'sine';
            osc3.frequency.setValueAtTime(783.99, audioContext.currentTime);
            gain3.gain.setValueAtTime(0.25, audioContext.currentTime);
            gain3.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
            osc3.start(audioContext.currentTime);
            osc3.stop(audioContext.currentTime + 0.5);
          }, 300);
          break;
          
        case 'unlock': // Premium unlock
          oscillator.type = 'triangle';
          oscillator.frequency.setValueAtTime(1000, audioContext.currentTime);
          oscillator.frequency.exponentialRampToValueAtTime(1500, audioContext.currentTime + 0.2);
          gainNode.gain.setValueAtTime(0.15, audioContext.currentTime);
          gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
          oscillator.start(audioContext.currentTime);
          oscillator.stop(audioContext.currentTime + 0.3);
          break;
          
        case 'droplet': // Keyboard typing
          oscillator.type = 'sine';
          oscillator.frequency.setValueAtTime(1200, audioContext.currentTime);
          gainNode.gain.setValueAtTime(0.08, audioContext.currentTime);
          gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.05);
          oscillator.start(audioContext.currentTime);
          oscillator.stop(audioContext.currentTime + 0.05);
          break;
          
        case 'whale': // Whale click
          oscillator.type = 'sine';
          oscillator.frequency.setValueAtTime(150, audioContext.currentTime);
          oscillator.frequency.exponentialRampToValueAtTime(80, audioContext.currentTime + 0.8);
          gainNode.gain.setValueAtTime(0.12, audioContext.currentTime);
          gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.8);
          oscillator.start(audioContext.currentTime);
          oscillator.stop(audioContext.currentTime + 0.8);
          break;
      }
    } catch(e) {
      // Audio not supported in browser
      console.log('Web Audio API not supported');
    }
  };
  
  const bibleVerses = [
    { text: "The plans of the diligent lead to profit as surely as haste leads to poverty.", reference: "Proverbs 21:5" },
    { text: "Commit to the Lord whatever you do, and he will establish your plans.", reference: "Proverbs 16:3" },
    { text: "Dishonest money dwindles away, but whoever gathers money little by little makes it grow.", reference: "Proverbs 13:11" },
    { text: "The borrower is slave to the lender.", reference: "Proverbs 22:7" },
    { text: "For where your treasure is, there your heart will be also.", reference: "Matthew 6:21" },
    { text: "Honor the Lord with your wealth and with the firstfruits of all your produce.", reference: "Proverbs 3:9" },
  ];

  const motivationalQuotes = [
    { text: "The stock market is a device for transferring money from the impatient to the patient.", author: "Warren Buffett" },
    { text: "Do not save what is left after spending, but spend what is left after saving.", author: "Warren Buffett" },
    { text: "An investment in knowledge pays the best interest.", author: "Benjamin Franklin" },
    { text: "Compound interest is the eighth wonder of the world.", author: "Albert Einstein" },
  ];

  const subscriptionPlans = {
    bronze: {
      name: 'Bronze Sailor',
      price: 9,
      period: 'month',
      annualPrice: 90,
      savings: 18,
      popular: false,
      features: [
        '10 Premium Learning Courses',
        'Basic Portfolio Analytics',
        '1 Automated Investment Strategy',
        'Community Access (The Reef)',
        'Monthly Market Reports',
        'Basic Debt Payoff Tools',
        'Email Support (48hr response)'
      ],
      tools: [
        { name: 'Basic Calculator Suite', icon: '🧮' },
        { name: 'Budget Templates', icon: '📊' },
        { name: 'Expense Tracker', icon: '💳' }
      ]
    },
    silver: {
      name: 'Silver Navigator',
      price: 29,
      period: 'month',
      annualPrice: 348,
      annualMonthly: 29,
      savings: 120,
      popular: true,
      features: [
        '✨ Everything in Bronze, plus:',
        '🤖 AI Financial Coach (Finn AI)',
        '⚙️ Autopilot Investing & Auto-Rebalancing',
        '💰 Automatic Tax-Loss Harvesting',
        '📊 Advanced Portfolio X-Ray Dashboard',
        '🎯 Retirement Crystal Ball (Monte Carlo)',
        '📈 50+ Premium Courses & Certifications',
        '🔔 Whale Alerts (Insider Trading Notifications)',
        '🧮 Premium Calculator Suite (10+ tools)',
        '💾 Document Vault (Unlimited Storage)',
        '🎓 1 Expert CFP Session per Year',
        '💳 1% Cash Back on Deposits',
        '⚡ Priority Support (24hr response)',
        '🏆 Sovereign Badge & Premium Pods'
      ],
      tools: [
        { name: 'Investment Calculator', icon: '📊' },
        { name: 'Tax Optimizer', icon: '📋' },
        { name: 'Retirement Planner', icon: '🏝️' },
        { name: 'Debt Destroyer Pro', icon: '💣' },
        { name: 'Asset Allocator', icon: '🎯' },
        { name: 'Dividend Tracker', icon: '💰' },
        { name: 'Compound Interest Visualizer', icon: '📈' },
        { name: 'Net Worth Tracker', icon: '💎' }
      ],
      strategies: [
        { name: 'The Dividend Sailor', return: '6-8%', risk: 'Low' },
        { name: 'Index Navigator', return: '8-10%', risk: 'Medium' },
        { name: 'Growth Voyager', return: '10-12%', risk: 'Medium-High' },
        { name: 'Tax Harvester', return: '9-12%', risk: 'Medium' },
        { name: 'ESG Captain', return: '7-9%', risk: 'Low-Medium' }
      ]
    },
    gold: {
      name: 'Gold Sovereign',
      price: 49,
      period: 'month',
      annualPrice: 588,
      annualMonthly: 49,
      savings: null,
      popular: false,
      features: [
        '⭐ Everything in Silver, plus:',
        '🚀 After-Hours Trading (7am-8pm)',
        '📱 Premium Metal Debit Card',
        '💳 3% Cash Back (Groceries, Gas, Dining)',
        '👨‍👩‍👧‍👦 Family Plan (Up to 4 Members)',
        '🎯 Advanced Order Types (Stop-Loss, Trailing)',
        '🔐 Identity Theft Protection + Credit Monitoring',
        '💼 Bill Negotiation Service',
        '✈️ Airport Lounge Access (2 visits/year)',
        '🌍 No Foreign Transaction Fees',
        '🎓 2 Expert CFP Sessions per Year',
        '🎟️ Quarterly Virtual Summits',
        '🏆 Gold-Only Investment Strategies',
        '⚡ VIP Support (12hr response)',
        '🎁 Partner Discounts (TurboTax, etc.)'
      ],
      tools: [
        { name: 'All Silver Tools', icon: '✨' },
        { name: 'Estate Planner', icon: '🏛️' },
        { name: 'College Savings Calculator', icon: '🎓' },
        { name: 'FIRE Calculator', icon: '🔥' },
        { name: 'Real Estate Analyzer', icon: '🏠' },
        { name: 'Business Valuation Tool', icon: '🏢' },
        { name: 'Options Strategy Builder', icon: '📊' }
      ],
      strategies: [
        { name: 'All Silver Strategies', return: 'Various', risk: 'Various' },
        { name: 'The Aggressive Whale', return: '12-18%', risk: 'High' },
        { name: 'Options Income Generator', return: '10-15%', risk: 'Medium-High' },
        { name: 'Real Estate REIT Portfolio', return: '8-12%', risk: 'Medium' },
        { name: 'International Diversifier', return: '9-13%', risk: 'Medium-High' },
        { name: 'Crypto Allocation (5%)', return: '15-40%', risk: 'Very High' }
      ],
      perks: [
        { name: 'Free ATM Withdrawals', icon: '🏧' },
        { name: 'Waived Wire Transfer Fees', icon: '💸' },
        { name: 'Concierge Service', icon: '🎩' },
        { name: 'Annual In-Person Summit Ticket', icon: '🎫' }
      ]
    }
  };

  const premiumTools = [
    {
      id: 1,
      name: 'Investment Calculator',
      icon: '📊',
      description: 'Project portfolio growth with compound interest',
      category: 'Planning Tools',
      tier: 'silver'
    },
    {
      id: 2,
      name: 'Tax Optimizer',
      icon: '📋',
      description: 'Minimize tax burden with smart strategies',
      category: 'Tax Tools',
      tier: 'silver'
    },
    {
      id: 3,
      name: 'Retirement Planner',
      icon: '🏝️',
      description: 'Monte Carlo simulation with 1000 scenarios',
      category: 'Planning Tools',
      tier: 'silver'
    },
    {
      id: 4,
      name: 'Asset Allocation Builder',
      icon: '🎯',
      description: 'Optimize portfolio allocation by risk tolerance',
      category: 'Investment Tools',
      tier: 'silver'
    },
    {
      id: 5,
      name: 'Dividend Tracker',
      icon: '💰',
      description: 'Track dividend income and DRIP reinvestment',
      category: 'Investment Tools',
      tier: 'silver'
    },
    {
      id: 6,
      name: 'Debt Destroyer Pro',
      icon: '💣',
      description: 'Custom payoff strategies + interest saved tracker',
      category: 'Debt Tools',
      tier: 'silver'
    },
    {
      id: 7,
      name: 'Portfolio X-Ray',
      icon: '🔬',
      description: 'Real-time health score, risk analysis, fee analyzer',
      category: 'Analytics',
      tier: 'silver'
    },
    {
      id: 8,
      name: 'Net Worth Tracker',
      icon: '💎',
      description: 'Track assets, liabilities, and net worth trends',
      category: 'Tracking',
      tier: 'silver'
    },
    {
      id: 9,
      name: 'Estate Planner',
      icon: '🏛️',
      description: 'Will generator, beneficiary tracker, legacy planning',
      category: 'Legacy Tools',
      tier: 'gold'
    },
    {
      id: 10,
      name: 'FIRE Calculator',
      icon: '🔥',
      description: 'Calculate your Financial Independence Retire Early date',
      category: 'Planning Tools',
      tier: 'gold'
    },
    {
      id: 11,
      name: 'College Savings Planner',
      icon: '🎓',
      description: '529 optimizer with projected education costs',
      category: 'Planning Tools',
      tier: 'gold'
    },
    {
      id: 12,
      name: 'Real Estate Analyzer',
      icon: '🏠',
      description: 'Cap rate, cash flow, and ROI calculator',
      category: 'Investment Tools',
      tier: 'gold'
    },
    {
      id: 13,
      name: 'Options Strategy Builder',
      icon: '📊',
      description: 'Design and backtest options strategies',
      category: 'Advanced Trading',
      tier: 'gold'
    },
    {
      id: 14,
      name: 'Business Valuation Tool',
      icon: '🏢',
      description: 'DCF, comparable analysis, and startup valuations',
      category: 'Business Tools',
      tier: 'gold'
    },
    {
      id: 15,
      name: 'AI Financial Coach',
      icon: '🤖',
      description: 'Daily personalized insights and spending analysis',
      category: 'AI Tools',
      tier: 'silver'
    },
    {
      id: 16,
      name: 'Document Vault',
      icon: '💾',
      description: 'Unlimited secure storage for financial documents',
      category: 'Storage',
      tier: 'silver'
    }
  ];

  const lessons = [
    {
      id: 1,
      title: 'Money Basics 101',
      depth: 'shallows',
      duration: '15 min',
      totalLessons: 5,
      icon: '💵',
      description: 'Understanding income, expenses, and budgeting',
      xpReward: 100,
      isPremium: false,
      content: {
        videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
        sections: [
          {
            title: 'What is Money?',
            content: 'Money is a medium of exchange that facilitates transactions. It serves three key functions: medium of exchange, store of value, and unit of account. Understanding money is the first step to financial literacy.',
            keyPoints: [
              'Money evolved from bartering systems',
              'Modern money is fiat currency (backed by government)',
              'Digital money is becoming increasingly common'
            ]
          },
          {
            title: 'Income vs Expenses',
            content: 'Income is money you earn from work, investments, or other sources. Expenses are the money you spend. The fundamental rule of personal finance: spend less than you earn.',
            keyPoints: [
              'Active income: Trading time for money (salary, hourly wages)',
              'Passive income: Money earned with minimal ongoing effort',
              'Fixed expenses: Rent, insurance (same each month)',
              'Variable expenses: Groceries, entertainment (changes monthly)'
            ]
          },
          {
            title: 'Creating Your First Budget',
            content: 'A budget is a plan for your money. The 50/30/20 rule is a simple starting point: 50% needs, 30% wants, 20% savings and debt repayment.',
            keyPoints: [
              'Track every dollar for one month',
              'Categorize spending into needs, wants, savings',
              'Adjust allocations based on your goals',
              'Review and update monthly'
            ],
            template: 'Download 50/30/20 Budget Template'
          },
          {
            title: 'Tracking Spending',
            content: 'You can\'t manage what you don\'t measure. Use apps, spreadsheets, or even pen and paper to track every expense.',
            keyPoints: [
              'Manual tracking: Write every expense down',
              'App-based: Mint, YNAB, EveryDollar',
              'Bank alerts: Set up notifications',
              'Weekly reviews: Catch overspending early'
            ]
          },
          {
            title: 'The 50/30/20 Rule',
            content: 'This budgeting framework allocates 50% to needs (housing, food, utilities), 30% to wants (entertainment, dining out), and 20% to savings and debt repayment.',
            keyPoints: [
              'Needs: Essential for survival',
              'Wants: Enhance your life but aren\'t necessary',
              'Savings: Emergency fund, retirement, investments',
              'Adjust percentages based on your situation'
            ]
          }
        ],
        quiz: [
          {
            question: 'What percentage of your income should go to needs in the 50/30/20 rule?',
            options: ['30%', '50%', '20%', '70%'],
            correct: 1
          },
          {
            question: 'Which is an example of passive income?',
            options: ['Hourly wage', 'Salary', 'Dividend payments', 'Overtime pay'],
            correct: 2
          }
        ]
      }
    },
    {
      id: 2,
      title: 'Stock Market Fundamentals',
      depth: 'reef',
      duration: '25 min',
      totalLessons: 7,
      icon: '📈',
      description: 'Learn how to invest in stocks and build wealth',
      xpReward: 150,
      isPremium: true,
      content: {
        videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
        sections: [
          {
            title: 'What Are Stocks?',
            content: 'When you buy stock, you\'re buying a small piece of ownership in a company. As the company grows and becomes more valuable, so does your investment.',
            keyPoints: [
              'Stock = equity = ownership in a company',
              'Share price represents market value',
              'You make money through price appreciation and dividends',
              'Risk: Company value can decrease'
            ]
          },
          {
            title: 'How Stock Markets Work',
            content: 'Stock markets are where buyers and sellers meet to trade stocks. The price is determined by supply and demand.',
            keyPoints: [
              'NYSE and NASDAQ are major US exchanges',
              'Market hours: 9:30 AM - 4:00 PM ET',
              'After-hours trading available',
              'Market makers facilitate trades'
            ]
          },
          {
            title: 'Reading Stock Charts',
            content: 'Stock charts visualize price movements over time. Learn to read candlestick patterns, volume, and trend lines.',
            keyPoints: [
              'Candlesticks show open, close, high, low prices',
              'Green = price went up, Red = price went down',
              'Volume indicates trading activity',
              'Support and resistance levels'
            ]
          },
          {
            title: 'Dividends Explained',
            content: 'Dividends are payments companies make to shareholders from profits. They provide passive income.',
            keyPoints: [
              'Dividend yield: Annual dividend / stock price',
              'Paid quarterly in most cases',
              'Dividend aristocrats: 25+ years of increases',
              'DRIP: Dividend Reinvestment Plan'
            ]
          },
          {
            title: 'Index Funds vs Individual Stocks',
            content: 'Index funds track market indices like the S&P 500, providing instant diversification. Individual stocks offer higher potential returns but higher risk.',
            keyPoints: [
              'Index funds: Diversified, lower risk, lower fees',
              'Individual stocks: Higher potential, requires research',
              'VOO, SPY track S&P 500',
              'Most investors should start with index funds'
            ]
          }
        ],
        quiz: [
          {
            question: 'What does buying a stock mean?',
            options: ['Lending money to a company', 'Buying company products', 'Owning part of a company', 'Betting on stock price'],
            correct: 2
          }
        ]
      }
    }
  ];

  const newsArticles = [
    {
      id: 1,
      title: 'Fed Signals Rate Cuts Coming in 2026',
      source: 'The Wall Street Journal',
      time: '2 hours ago',
      category: 'Markets',
      summary: 'Federal Reserve Chairman indicates potential interest rate cuts as inflation moderates.',
      url: 'https://wsj.com',
      image: '📰'
    },
    {
      id: 2,
      title: 'Tech Stocks Rally on AI Earnings',
      source: 'Bloomberg',
      time: '4 hours ago',
      category: 'Technology',
      summary: 'Major tech companies beat earnings expectations driven by AI revenue growth.',
      url: 'https://bloomberg.com',
      image: '💻'
    },
    {
      id: 3,
      title: 'Bitcoin Crosses $70,000 Mark',
      source: 'CNBC',
      time: '6 hours ago',
      category: 'Crypto',
      summary: 'Cryptocurrency markets surge as institutional adoption continues to grow.',
      url: 'https://cnbc.com',
      image: '₿'
    },
    {
      id: 4,
      title: 'Housing Market Shows Signs of Recovery',
      source: 'Reuters',
      time: '8 hours ago',
      category: 'Real Estate',
      summary: 'Home sales increase for third consecutive month as mortgage rates stabilize.',
      url: 'https://reuters.com',
      image: '🏠'
    },
    {
      id: 5,
      title: 'New Tax Credits for Electric Vehicles',
      source: 'Apple News',
      time: '1 day ago',
      category: 'Policy',
      summary: 'Government expands EV tax incentives, making electric cars more affordable.',
      url: 'https://apple.news',
      image: '⚡'
    }
  ];

  const marketData = [
    { symbol: 'SPY', name: 'S&P 500', price: 542.18, change: +2.34, changePercent: +0.43, trend: 'up' },
    { symbol: 'QQQ', name: 'Nasdaq', price: 438.92, change: +5.67, changePercent: +1.31, trend: 'up' },
    { symbol: 'AAPL', name: 'Apple', price: 178.45, change: -1.23, changePercent: -0.68, trend: 'down' },
    { symbol: 'TSLA', name: 'Tesla', price: 234.56, change: +8.91, changePercent: +3.95, trend: 'up' },
    { symbol: 'BTC-USD', name: 'Bitcoin', price: 68234.12, change: -423.56, changePercent: -0.62, trend: 'down' },
  ];

  // Initialize posts
  useEffect(() => {
    setReefPosts([
      {
        id: 1,
        author: 'TidalTrader',
        avatar: '🐙',
        rank: 'Blue Whale',
        timestamp: '2 hours ago',
        content: 'Just hit my emergency fund goal of $10k! The Snowball method worked perfectly for paying off debt first. Now onto building investments! 🎉',
        likes: 127,
        dislikes: 2,
        userVote: null,
        replies: [
          {
            id: 101,
            author: 'WaveRider',
            avatar: '🦈',
            rank: 'Narwhal',
            timestamp: '1 hour ago',
            content: 'Congrats! That\'s a huge milestone. What\'s your next goal?',
            likes: 15,
            dislikes: 0,
            userVote: null
          }
        ]
      },
      {
        id: 2,
        author: 'WaveRider',
        avatar: '🦈',
        rank: 'Narwhal',
        timestamp: '5 hours ago',
        content: 'PSA: Don\'t sleep on I-Bonds right now. With inflation still above 3%, they\'re beating most HYSA rates. Lock in that 5.27% while you can!',
        likes: 89,
        dislikes: 5,
        userVote: null,
        replies: []
      }
    ]);
  }, []);

  const handleWhaleClick = () => {
    playSound('whale');
    const allQuotes = [...bibleVerses, ...motivationalQuotes];
    const randomQuote = allQuotes[Math.floor(Math.random() * allQuotes.length)];
    setCurrentQuote(randomQuote);
    setShowQuoteModal(true);
  };

  const handleKeyPress = (key) => {
    playSound('droplet');
    if (key === '←') {
      setCurrentGuess(currentGuess.slice(0, -1));
    } else if (key === 'ENTER') {
      handleGuessSubmit();
    } else if (currentGuess.length < 5) {
      setCurrentGuess(currentGuess + key);
    }
  };

  const handleGuessSubmit = () => {
    if (currentGuess.length !== 5) return;
    playSound('bubble');
    const newGuess = currentGuess.toUpperCase();
    setGuesses([...guesses, newGuess]);
    if (newGuess === todaysWord) {
      setGameWon(true);
      setBarnaclePoints(barnaclePoints + 50);
      setTimeout(() => playSound('success'), 200);
    }
    setCurrentGuess('');
  };

  const getLetterColor = (letter, position, word) => {
    if (word[position] === letter) return 'correct';
    if (todaysWord.includes(letter)) return 'present';
    return 'absent';
  };

  const handleLessonClick = (lesson) => {
    playSound('bubble');
    if (lesson.isPremium && !isPremium) {
      setShowPaywall(true);
    } else {
      setCurrentLesson(lesson);
      setShowLessonModal(true);
    }
  };

  const handleSubscribe = () => {
    playSound('unlock');
    setTimeout(() => playSound('success'), 300);
    setIsPremium(true);
    setShowPaywall(false);
    alert(`Welcome to The Sovereign Club! You're now subscribed to the ${selectedPlan} plan.`);
  };

  const handleVote = (postId, voteType, isReply, parentId) => {
    playSound('bubble');
    setReefPosts(posts => posts.map(post => {
      if (isReply && post.id === parentId) {
        return {
          ...post,
          replies: post.replies.map(reply => {
            if (reply.id === postId) {
              const newVote = reply.userVote === voteType ? null : voteType;
              return {
                ...reply,
                likes: newVote === 'up' ? reply.likes + 1 : reply.userVote === 'up' ? reply.likes - 1 : reply.likes,
                dislikes: newVote === 'down' ? reply.dislikes + 1 : reply.userVote === 'down' ? reply.dislikes - 1 : reply.dislikes,
                userVote: newVote
              };
            }
            return reply;
          })
        };
      } else if (post.id === postId) {
        const newVote = post.userVote === voteType ? null : voteType;
        return {
          ...post,
          likes: newVote === 'up' ? post.likes + 1 : post.userVote === 'up' ? post.likes - 1 : post.likes,
          dislikes: newVote === 'down' ? post.dislikes + 1 : post.userVote === 'down' ? post.dislikes - 1 : post.dislikes,
          userVote: newVote
        };
      }
      return post;
    }));
  };

  const handleNewPost = () => {
    if (!newPostContent.trim()) return;
    playSound('success');
    const newPost = {
      id: Date.now(),
      author: 'You',
      avatar: '🐠',
      rank: 'Dolphin',
      timestamp: 'Just now',
      content: newPostContent,
      likes: 0,
      dislikes: 0,
      userVote: null,
      replies: []
    };
    setReefPosts([newPost, ...reefPosts]);
    setNewPostContent('');
    setShowNewPostModal(false);
  };

  const handleReply = (postId) => {
    if (!replyContent.trim()) return;
    playSound('bubble');
    setReefPosts(posts => posts.map(post => {
      if (post.id === postId) {
        return {
          ...post,
          replies: [...post.replies, {
            id: Date.now(),
            author: 'You',
            avatar: '🐠',
            rank: 'Dolphin',
            timestamp: 'Just now',
            content: replyContent,
            likes: 0,
            dislikes: 0,
            userVote: null
          }]
        };
      }
      return post;
    }));
    setReplyContent('');
    setReplyingTo(null);
  };

  const RealisticWhale = ({ animate }) => (
    <div className={`whale-container ${animate ? 'whale-pulse' : ''}`} onClick={handleWhaleClick}>
      <svg width="140" height="100" viewBox="0 0 140 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <linearGradient id="whaleBody" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#4A9FFF" />
            <stop offset="50%" stopColor="#2E7FCC" />
            <stop offset="100%" stopColor="#1A5F99" />
          </linearGradient>
          <linearGradient id="whaleBelly" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#E8F4FF" stopOpacity="0.95" />
            <stop offset="100%" stopColor="#B3D9FF" stopOpacity="0.85" />
          </linearGradient>
          <filter id="dropShadow">
            <feDropShadow dx="0" dy="6" stdDeviation="6" floodOpacity="0.25"/>
          </filter>
        </defs>
        
        <g filter="url(#dropShadow)">
          <ellipse cx="70" cy="55" rx="50" ry="30" fill="url(#whaleBody)"/>
          <ellipse cx="70" cy="65" rx="40" ry="22" fill="url(#whaleBelly)" opacity="0.75"/>
          <path d="M 20 55 Q 10 45 12 35 Q 15 28 18 35 Q 21 45 20 55 Z" fill="url(#whaleBody)"/>
          <path d="M 20 55 Q 10 65 12 75 Q 15 82 18 75 Q 21 65 20 55 Z" fill="url(#whaleBody)"/>
          <ellipse cx="60" cy="78" rx="14" ry="7" fill="url(#whaleBody)" opacity="0.85" transform="rotate(-25 60 78)"/>
          <ellipse cx="80" cy="80" rx="14" ry="7" fill="url(#whaleBody)" opacity="0.85" transform="rotate(25 80 80)"/>
          <circle cx="95" cy="48" r="5" fill="#1A1A2E" opacity="0.9"/>
          <circle cx="96.5" cy="46.5" r="2" fill="#FFFFFF" opacity="0.95"/>
          <path d="M 85 60 Q 92 63 99 60" stroke="#1A1A2E" strokeWidth="2.5" fill="none" strokeLinecap="round" opacity="0.65"/>
          
          <g className="water-spout">
            <path d="M 72 25 L 72 8" stroke="#4A9FFF" strokeWidth="3.5" strokeLinecap="round" opacity="0.7"/>
            <path d="M 67 20 L 67 12" stroke="#4A9FFF" strokeWidth="2.5" strokeLinecap="round" opacity="0.6"/>
            <path d="M 77 20 L 77 12" stroke="#4A9FFF" strokeWidth="2.5" strokeLinecap="round" opacity="0.6"/>
            <circle cx="72" cy="6" r="2.5" fill="#4A9FFF" opacity="0.5"/>
          </g>
          
          {animate && (
            <g className="captain-hat">
              <ellipse cx="75" cy="30" rx="20" ry="6" fill="#FFD700" filter="url(#dropShadow)"/>
              <rect x="58" y="30" width="34" height="14" rx="3" fill="#FFD700"/>
              <rect x="64" y="34" width="22" height="7" fill="#FFA500"/>
            </g>
          )}
        </g>
      </svg>
    </div>
  );

  const Keyboard = () => {
    const rows = [
      ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P'],
      ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L'],
      ['ENTER', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', '←']
    ];

    const getKeyStatus = (key) => {
      if (key === 'ENTER' || key === '←') return '';
      
      for (let guess of guesses) {
        for (let i = 0; i < guess.length; i++) {
          if (guess[i] === key) {
            if (todaysWord[i] === key) return 'correct';
            if (todaysWord.includes(key)) return 'present';
            return 'absent';
          }
        }
      }
      return '';
    };

    return (
      <div className="keyboard">
        {rows.map((row, i) => (
          <div key={i} className="keyboard-row">
            {row.map(key => (
              <button
                key={key}
                onClick={() => handleKeyPress(key)}
                className={`key ${getKeyStatus(key)} ${key.length > 1 ? 'key-wide' : ''}`}
                disabled={gameWon || guesses.length >= 6}
              >
                {key}
              </button>
            ))}
          </div>
        ))}
      </div>
    );
  };

  const PaywallModal = () => {
    const [selectedTier, setSelectedTier] = useState('silver');
    const [billingCycle, setBillingCycle] = useState('annual');

    const getCurrentPlan = () => subscriptionPlans[selectedTier];
    const currentPlan = getCurrentPlan();
    const displayPrice = billingCycle === 'annual' 
      ? (currentPlan.annualPrice || currentPlan.price * 12) 
      : currentPlan.price;
    const monthlyEquiv = billingCycle === 'annual'
      ? Math.floor(displayPrice / 12)
      : currentPlan.price;

    return (
      <div className="modal-overlay" onClick={() => setShowPaywall(false)}>
        <div className="paywall-modal-large" onClick={e => e.stopPropagation()}>
          <button className="modal-close" onClick={() => setShowPaywall(false)}>
            <X size={24} />
          </button>
          
          <div className="paywall-header">
            <Crown className="paywall-icon" size={56} />
            <h2 className="paywall-title">Choose Your Journey</h2>
            <p className="paywall-subtitle">Unlock the features that match your financial goals</p>
          </div>

          {/* Billing Toggle */}
          <div className="billing-toggle">
            <button 
              className={`billing-btn ${billingCycle === 'monthly' ? 'active' : ''}`}
              onClick={() => setBillingCycle('monthly')}
            >
              Monthly
            </button>
            <button 
              className={`billing-btn ${billingCycle === 'annual' ? 'active' : ''}`}
              onClick={() => setBillingCycle('annual')}
            >
              Annual
              <span className="save-badge">Save up to $120</span>
            </button>
          </div>

          {/* Tier Selection */}
          <div className="tier-selector">
            <button 
              className={`tier-card ${selectedTier === 'bronze' ? 'active' : ''}`}
              onClick={() => setSelectedTier('bronze')}
            >
              <div className="tier-icon">🥉</div>
              <div className="tier-name">Bronze Sailor</div>
              <div className="tier-price">${billingCycle === 'annual' ? '8' : '9'}</div>
              <div className="tier-period">per month</div>
            </button>

            <button 
              className={`tier-card ${selectedTier === 'silver' ? 'active' : ''} popular`}
              onClick={() => setSelectedTier('silver')}
            >
              <div className="popular-badge">MOST POPULAR</div>
              <div className="tier-icon">🥈</div>
              <div className="tier-name">Silver Navigator</div>
              <div className="tier-price">${monthlyEquiv}</div>
              <div className="tier-period">per month</div>
            </button>

            <button 
              className={`tier-card ${selectedTier === 'gold' ? 'active' : ''}`}
              onClick={() => setSelectedTier('gold')}
            >
              <div className="tier-icon">🥇</div>
              <div className="tier-name">Gold Sovereign</div>
              <div className="tier-price">$49</div>
              <div className="tier-period">per month</div>
            </button>
          </div>

          {/* Selected Plan Details */}
          <div className="plan-details">
            <h3 className="plan-details-title">{currentPlan.name} Includes:</h3>
            <div className="features-grid">
              {currentPlan.features.map((feature, i) => (
                <div key={i} className="feature-item-compact">
                  <Zap size={14} className="feature-check" />
                  <span>{feature}</span>
                </div>
              ))}
            </div>

            {currentPlan.tools && (
              <div className="tools-preview">
                <h4 className="tools-preview-title">Premium Tools:</h4>
                <div className="tools-grid-compact">
                  {currentPlan.tools.slice(0, 6).map((tool, i) => (
                    <div key={i} className="tool-chip">
                      <span className="tool-chip-icon">{tool.icon}</span>
                      <span className="tool-chip-name">{tool.name}</span>
                    </div>
                  ))}
                  {currentPlan.tools.length > 6 && (
                    <div className="tool-chip more">
                      +{currentPlan.tools.length - 6} more
                    </div>
                  )}
                </div>
              </div>
            )}

            {selectedTier !== 'bronze' && currentPlan.strategies && (
              <div className="strategies-preview">
                <h4 className="strategies-preview-title">Investment Strategies:</h4>
                <div className="strategies-list-compact">
                  {currentPlan.strategies.slice(0, 3).map((strategy, i) => (
                    <div key={i} className="strategy-chip">
                      {strategy.name} • {strategy.return}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Value Stack */}
          <div className="value-stack">
            <div className="value-stack-title">Total Value:</div>
            <div className="value-items">
              {selectedTier === 'silver' && (
                <>
                  <div className="value-item">Tax Savings: <span>$2,000+/year</span></div>
                  <div className="value-item">AI Coach: <span>$1,200/year</span></div>
                  <div className="value-item">Expert Sessions: <span>$400/year</span></div>
                  <div className="value-item">Premium Tools: <span>$300/year</span></div>
                </>
              )}
              {selectedTier === 'gold' && (
                <>
                  <div className="value-item">All Silver Value: <span>$3,900/year</span></div>
                  <div className="value-item">Family Plan: <span>$600/year</span></div>
                  <div className="value-item">3% Cash Back: <span>$500+/year</span></div>
                  <div className="value-item">Extra CFP Session: <span>$200/year</span></div>
                </>
              )}
              {selectedTier === 'bronze' && (
                <>
                  <div className="value-item">Courses: <span>$200/year</span></div>
                  <div className="value-item">Community: <span>$100/year</span></div>
                  <div className="value-item">Tools: <span>$150/year</span></div>
                </>
              )}
            </div>
            <div className="value-total">
              <div className="value-total-label">You Pay:</div>
              <div className="value-total-price">
                ${displayPrice}/{billingCycle === 'annual' ? 'year' : 'month'}
              </div>
            </div>
          </div>

          <button className="subscribe-btn-large" onClick={() => {
            playSound('unlock');
            setTimeout(() => playSound('success'), 300);
            setIsPremium(true);
            setShowPaywall(false);
            alert(\`Welcome to \${currentPlan.name}! You're now subscribed.\`);
          }}>
            Start 7-Day Free Trial
          </button>
          
          <p className="paywall-disclaimer">
            No credit card required • Cancel anytime • Money-back guarantee
          </p>

          <div className="guarantee-badge">
            💎 If you don't save at least \${displayPrice} in your first year, we'll refund everything
          </div>
        </div>
      </div>
    );
  };

  const LessonModal = () => {
    if (!currentLesson) return null;
    const [currentSection, setCurrentSection] = useState(0);

    return (
      <div className="modal-overlay" onClick={() => setShowLessonModal(false)}>
        <div className="lesson-modal" onClick={e => e.stopPropagation()}>
          <button className="modal-close" onClick={() => setShowLessonModal(false)}>
            <X size={24} />
          </button>

          <div className="lesson-header">
            <div className="lesson-icon">{currentLesson.icon}</div>
            <h2 className="lesson-title">{currentLesson.title}</h2>
            <p className="lesson-meta">{currentLesson.duration} • {currentLesson.totalLessons} lessons</p>
          </div>

          <div className="lesson-progress-bar">
            <div 
              className="lesson-progress-fill" 
              style={{ width: `${((currentSection + 1) / currentLesson.content.sections.length) * 100}%` }}
            />
          </div>

          <div className="lesson-video">
            <div className="video-placeholder">
              <Play size={64} className="play-icon" />
              <p className="video-label">Lesson Video</p>
              <p className="video-link">Watch on YouTube ↗</p>
            </div>
          </div>

          <div className="lesson-content">
            <h3 className="section-title">
              {currentLesson.content.sections[currentSection].title}
            </h3>
            <p className="section-content">
              {currentLesson.content.sections[currentSection].content}
            </p>

            <div className="key-points">
              <h4 className="key-points-title">Key Points:</h4>
              <ul className="key-points-list">
                {currentLesson.content.sections[currentSection].keyPoints.map((point, i) => (
                  <li key={i}>{point}</li>
                ))}
              </ul>
            </div>

            {currentLesson.content.sections[currentSection].template && (
              <button className="template-btn">
                <Download size={16} />
                {currentLesson.content.sections[currentSection].template}
              </button>
            )}
          </div>

          <div className="lesson-nav">
            <button 
              className="lesson-nav-btn"
              onClick={() => setCurrentSection(Math.max(0, currentSection - 1))}
              disabled={currentSection === 0}
            >
              Previous
            </button>
            <span className="lesson-counter">
              {currentSection + 1} / {currentLesson.content.sections.length}
            </span>
            <button 
              className="lesson-nav-btn primary"
              onClick={() => {
                if (currentSection < currentLesson.content.sections.length - 1) {
                  setCurrentSection(currentSection + 1);
                } else {
                  alert(`Congrats! You earned +${currentLesson.xpReward} XP`);
                  setKnowledgeXP(knowledgeXP + currentLesson.xpReward);
                  setShowLessonModal(false);
                }
              }}
            >
              {currentSection < currentLesson.content.sections.length - 1 ? 'Next' : 'Complete'}
            </button>
          </div>
        </div>
      </div>
    );
  };

  const NewPostModal = () => (
    <div className="modal-overlay" onClick={() => setShowNewPostModal(false)}>
      <div className="new-post-modal" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <h3 className="modal-title">Share with The Reef</h3>
          <button className="modal-close" onClick={() => setShowNewPostModal(false)}>
            <X size={20} />
          </button>
        </div>

        <textarea
          className="post-textarea"
          placeholder="Share your financial journey, ask questions, or give advice..."
          value={newPostContent}
          onChange={(e) => setNewPostContent(e.target.value)}
          rows={6}
        />

        <div className="post-actions">
          <div className="character-count">{newPostContent.length}/500</div>
          <button 
            className="post-submit-btn" 
            onClick={handleNewPost}
            disabled={!newPostContent.trim()}
          >
            <Send size={16} />
            Post
          </button>
        </div>
      </div>
    </div>
  );

  const HomeView = () => (
    <div className={`view-container ${isTransitioning ? 'transitioning' : ''}`}>
      <div className="hero">
        <RealisticWhale animate={dailyStreak >= 7} />
        <h1 className="hero-title">Welcome back, Captain</h1>
        <p className="hero-subtitle">Your financial ocean is looking mighty clear today</p>
      </div>

      {!isPremium && (
        <div className="glass-card float premium-banner" onClick={() => setShowPaywall(true)}>
          <Crown size={28} />
          <div className="banner-content">
            <div className="banner-title">Join The Sovereign Club</div>
            <div className="banner-subtitle">Unlock premium tools, courses & templates</div>
          </div>
          <ChevronRight size={20} className="banner-arrow" />
        </div>
      )}

      <div className="stats-grid">
        <div className="glass-card stat-card float">
          <div className="stat-icon">🔥</div>
          <div className="stat-value">{dailyStreak}</div>
          <div className="stat-label">Day Streak</div>
        </div>
        <div className="glass-card stat-card float">
          <div className="stat-icon">💰</div>
          <div className="stat-value">{barnaclePoints}</div>
          <div className="stat-label">Barnacle Bucks</div>
        </div>
        <div className="glass-card stat-card float">
          <div className="stat-icon">🎓</div>
          <div className="stat-value">{knowledgeXP}</div>
          <div className="stat-label">Learning XP</div>
        </div>
      </div>

      <div className="glass-card">
        <h3 className="section-title">Today's Missions</h3>
        <div className="action-list">
          <div className="action-item" onClick={() => setActiveTab('vault')}>
            <div className="action-icon">📝</div>
            <div className="action-content">
              <div className="action-name">Crack the Vault</div>
              <div className="action-desc">Daily financial wordle • 50 BB</div>
            </div>
            <ChevronRight size={20} className="action-arrow" />
          </div>
          
          <div className="action-item" onClick={() => setActiveTab('depths')}>
            <div className="action-icon">🎓</div>
            <div className="action-content">
              <div className="action-name">Learn Something New</div>
              <div className="action-desc">Explore The Depths academy</div>
            </div>
            <ChevronRight size={20} className="action-arrow" />
          </div>
        </div>
      </div>

      {isPremium && (
        <div className="glass-card">
          <h3 className="section-title">Premium Tools</h3>
          <div className="tools-grid">
            {premiumTools.slice(0, 3).map(tool => (
              <div key={tool.id} className="tool-item">
                <div className="tool-icon-large">{tool.icon}</div>
                <div className="tool-name">{tool.name}</div>
                <div className="tool-category">{tool.category}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );

  const VaultView = () => (
    <div className={`view-container ${isTransitioning ? 'transitioning' : ''}`}>
      <div className="page-header">
        <h2 className="page-title">The Vault</h2>
        <p className="page-subtitle">Guess today's 5-letter financial term</p>
      </div>

      <div className="glass-card wordle-container">
        <div className="wordle-grid">
          {[0, 1, 2, 3, 4, 5].map(rowIndex => (
            <div key={rowIndex} className="wordle-row">
              {[0, 1, 2, 3, 4].map(colIndex => {
                const guess = rowIndex === guesses.length ? currentGuess : guesses[rowIndex];
                const letter = guess ? guess[colIndex] : '';
                const colorClass = (guess && rowIndex < guesses.length) ? getLetterColor(letter, colIndex, guess) : '';
                return (
                  <div key={colIndex} className={`wordle-tile ${colorClass}`}>
                    {letter}
                  </div>
                );
              })}
            </div>
          ))}
        </div>

        {!gameWon && guesses.length < 6 && <Keyboard />}

        {gameWon && (
          <div className="win-message">
            <Zap size={32} className="win-icon" />
            <div className="win-text">Perfect! You earned +50 BB</div>
            <div className="win-definition">
              <strong>STOCK:</strong> A share representing ownership in a company
            </div>
          </div>
        )}

        {!gameWon && guesses.length >= 6 && (
          <div className="loss-message">
            <div className="loss-text">The word was: <strong>{todaysWord}</strong></div>
            <div className="loss-subtext">Come back tomorrow for another try!</div>
          </div>
        )}
      </div>
    </div>
  );

  const DepthsView = () => (
    <div className={`view-container ${isTransitioning ? 'transitioning' : ''}`}>
      <div className="page-header">
        <h2 className="page-title">The Depths</h2>
        <p className="page-subtitle">Navigate your financial learning journey</p>
      </div>

      <div className="glass-card float">
        <div className="progress-header">
          <div className="progress-label">Learning Progress</div>
          <div className="progress-value">{knowledgeXP} XP</div>
        </div>
        <div className="xp-bar">
          <div className="xp-fill" style={{ width: `${(knowledgeXP / 2000) * 100}%` }}></div>
        </div>
        <div className="xp-subtext">
          {2000 - knowledgeXP} XP until next reward
        </div>
      </div>

      <div className="lessons-list">
        {lessons.map(lesson => (
          <div 
            key={lesson.id} 
            className="glass-card lesson-card"
            onClick={() => handleLessonClick(lesson)}
          >
            {lesson.isPremium && !isPremium && (
              <div className="premium-badge">
                <Lock size={12} />
                <span>Sovereign</span>
              </div>
            )}
            
            <div className="lesson-card-header">
              <div className="lesson-icon">{lesson.icon}</div>
              <div className="lesson-info">
                <div className="lesson-title">{lesson.title}</div>
                <div className="lesson-meta">
                  {lesson.depth === 'shallows' ? '🏖️ The Shallows' : '🪸 The Reef'} • {lesson.duration} • {lesson.totalLessons} lessons
                </div>
              </div>
            </div>
            
            <div className="lesson-desc">{lesson.description}</div>
            
            <div className="lesson-footer">
              <div className="lesson-reward">
                <Zap size={16} />
                <span>+{lesson.xpReward} XP</span>
              </div>
              <ChevronRight size={20} className="lesson-arrow" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const TidesView = () => (
    <div className={`view-container ${isTransitioning ? 'transitioning' : ''}`}>
      <div className="page-header">
        <h2 className="page-title">The Tides</h2>
        <p className="page-subtitle">Live markets & financial news</p>
      </div>

      <div className="glass-card">
        <h3 className="section-title">Market Overview</h3>
        <div className="market-grid">
          {marketData.map(stock => (
            <div key={stock.symbol} className="market-item">
              <div className="market-symbol">{stock.symbol}</div>
              <div className="market-name">{stock.name}</div>
              <div className="market-price">${stock.price.toLocaleString()}</div>
              <div className={`market-change ${stock.trend}`}>
                {stock.trend === 'up' ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
                {stock.change >= 0 ? '+' : ''}{stock.change.toFixed(2)} ({stock.changePercent.toFixed(2)}%)
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="glass-card">
        <h3 className="section-title">Latest News</h3>
        <div className="news-list">
          {newsArticles.map(article => (
            <div key={article.id} className="news-item" onClick={() => window.open(article.url, '_blank')}>
              <div className="news-icon">{article.image}</div>
              <div className="news-content">
                <div className="news-header">
                  <span className="news-source">{article.source}</span>
                  <span className="news-time">{article.time}</span>
                </div>
                <div className="news-title">{article.title}</div>
                <div className="news-summary">{article.summary}</div>
                <div className="news-category">{article.category}</div>
              </div>
              <ExternalLink size={16} className="news-link-icon" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const ReefView = () => (
    <div className={`view-container ${isTransitioning ? 'transitioning' : ''}`}>
      <div className="page-header">
        <h2 className="page-title">The Reef</h2>
        <p className="page-subtitle">Community discussions & shared wisdom</p>
      </div>

      <button className="new-post-btn" onClick={() => setShowNewPostModal(true)}>
        <span className="new-post-icon">✍️</span>
        <span>Share your journey...</span>
      </button>

      <div className="posts-list">
        {reefPosts.map(post => (
          <div key={post.id} className="glass-card post-card">
            <div className="post-header">
              <div className="post-author">
                <span className="post-avatar">{post.avatar}</span>
                <div className="post-author-info">
                  <div className="post-author-name">{post.author}</div>
                  <div className="post-meta">
                    <span className="post-rank">{post.rank}</span> • <span>{post.timestamp}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="post-content">{post.content}</div>

            <div className="post-actions">
              <button 
                className={`post-action ${post.userVote === 'up' ? 'active' : ''}`}
                onClick={() => handleVote(post.id, 'up', false)}
              >
                <ThumbsUp size={16} />
                <span>{post.likes}</span>
              </button>
              <button 
                className={`post-action ${post.userVote === 'down' ? 'active' : ''}`}
                onClick={() => handleVote(post.id, 'down', false)}
              >
                <ThumbsDown size={16} />
                <span>{post.dislikes}</span>
              </button>
              <button 
                className="post-action"
                onClick={() => setReplyingTo(replyingTo === post.id ? null : post.id)}
              >
                <MessageCircle size={16} />
                <span>{post.replies.length}</span>
              </button>
            </div>

            {post.replies.length > 0 && (
              <div className="replies-list">
                {post.replies.map(reply => (
                  <div key={reply.id} className="reply-item">
                    <div className="reply-header">
                      <span className="reply-avatar">{reply.avatar}</span>
                      <div className="reply-author-info">
                        <span className="reply-author">{reply.author}</span>
                        <span className="reply-meta">{reply.rank} • {reply.timestamp}</span>
                      </div>
                    </div>
                    <div className="reply-content">{reply.content}</div>
                    <div className="reply-actions">
                      <button 
                        className={`reply-action ${reply.userVote === 'up' ? 'active' : ''}`}
                        onClick={() => handleVote(reply.id, 'up', true, post.id)}
                      >
                        <ThumbsUp size={14} />
                        <span>{reply.likes}</span>
                      </button>
                      <button 
                        className={`reply-action ${reply.userVote === 'down' ? 'active' : ''}`}
                        onClick={() => handleVote(reply.id, 'down', true, post.id)}
                      >
                        <ThumbsDown size={14} />
                        <span>{reply.dislikes}</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {replyingTo === post.id && (
              <div className="reply-input-section">
                <input
                  type="text"
                  className="reply-input"
                  placeholder="Write a reply..."
                  value={replyContent}
                  onChange={(e) => setReplyContent(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleReply(post.id)}
                />
                <button className="reply-send-btn" onClick={() => handleReply(post.id)}>
                  <Send size={16} />
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );

  const QuoteModal = () => {
    if (!currentQuote) return null;
    
    return (
      <div className="quote-overlay" onClick={() => setShowQuoteModal(false)}>
        <div className="quote-modal" onClick={e => e.stopPropagation()}>
          <div className="quote-whale">🐋</div>
          <div className="quote-text">"{currentQuote.text}"</div>
          <div className="quote-source">
            {currentQuote.reference || `— ${currentQuote.author}`}
          </div>
          <button className="quote-btn" onClick={() => setShowQuoteModal(false)}>
            Continue Your Journey
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="lifevest-app">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }

        body {
          font-family: -apple-system, BlinkMacSystemFont, 'Inter', 'SF Pro Display', sans-serif;
          -webkit-font-smoothing: antialiased;
          -moz-osx-font-smoothing: grayscale;
        }

        .lifevest-app {
          min-height: 100vh;
          background: 
            radial-gradient(ellipse at 20% 10%, rgba(0, 212, 255, 0.12) 0%, transparent 50%),
            radial-gradient(ellipse at 80% 90%, rgba(0, 150, 255, 0.08) 0%, transparent 50%),
            linear-gradient(180deg, #001529 0%, #000a14 100%);
          color: #ffffff;
          padding-bottom: 100px;
          position: relative;
          overflow-x: hidden;
          /* Enable hardware acceleration */
          transform: translateZ(0);
          -webkit-transform: translateZ(0);
          backface-visibility: hidden;
          -webkit-backface-visibility: hidden;
        }

        .lifevest-app::before {
          content: '';
          position: fixed;
          inset: 0;
          background-image: 
            radial-gradient(circle at 25% 25%, rgba(0, 212, 255, 0.04) 0%, transparent 40%),
            radial-gradient(circle at 75% 75%, rgba(0, 212, 255, 0.03) 0%, transparent 40%);
          animation: drift 45s ease-in-out infinite alternate;
          pointer-events: none;
          z-index: 0;
          will-change: transform;
        }

        @keyframes drift {
          0% { transform: translate3d(0, 0, 0); }
          100% { transform: translate3d(25px, -25px, 0); }
        }

        .view-container {
          padding: 32px 20px;
          max-width: 680px;
          margin: 0 auto;
          position: relative;
          z-index: 1;
          /* GPU acceleration */
          transform: translateZ(0);
          -webkit-transform: translateZ(0);
          will-change: transform, opacity;
          backface-visibility: hidden;
          -webkit-backface-visibility: hidden;
          perspective: 1000px;
          -webkit-perspective: 1000px;
        }

        /* Smooth page entrance */
        .view-container {
          animation: smoothPageIn 0.5s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }

        @keyframes smoothPageIn {
          0% {
            opacity: 0;
            transform: translate3d(40px, 0, 0) scale(0.96);
          }
          100% {
            opacity: 1;
            transform: translate3d(0, 0, 0) scale(1);
          }
        }

        /* Smooth page exit - only when transitioning */
        .view-container.transitioning {
          animation: smoothPageOut 0.35s cubic-bezier(0.4, 0, 1, 1) forwards;
        }

        @keyframes smoothPageOut {
          0% {
            opacity: 1;
            transform: translate3d(0, 0, 0) scale(1);
          }
          100% {
            opacity: 0;
            transform: translate3d(-40px, 0, 0) scale(0.96);
          }
        }

        .glass-card {
          background: rgba(255, 255, 255, 0.05);
          backdrop-filter: blur(60px) saturate(200%);
          -webkit-backdrop-filter: blur(60px) saturate(200%);
          border: 0.5px solid rgba(255, 255, 255, 0.1);
          border-radius: 20px;
          padding: 24px;
          margin-bottom: 16px;
          transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
          /* GPU acceleration for smooth animations */
          transform: translateZ(0);
          -webkit-transform: translateZ(0);
          will-change: transform, box-shadow, border-color;
          backface-visibility: hidden;
          -webkit-backface-visibility: hidden;
        }

        .glass-card:hover {
          transform: translate3d(0, -6px, 0);
          box-shadow: 0 16px 48px rgba(0, 0, 0, 0.25);
          border-color: rgba(255, 255, 255, 0.18);
        }

        .glass-card.float {
          animation: gentleFloat 6s ease-in-out infinite;
        }

        @keyframes gentleFloat {
          0%, 100% { transform: translate3d(0, 0, 0); }
          50% { transform: translate3d(0, -10px, 0); }
        }

        .glass-card.float:nth-child(2) { animation-delay: 0.3s; }
        .glass-card.float:nth-child(3) { animation-delay: 0.6s; }
        .glass-card.float:nth-child(4) { animation-delay: 0.9s; }

        .whale-container {
          display: flex;
          justify-content: center;
          margin: 40px auto;
          cursor: pointer;
          filter: drop-shadow(0 12px 40px rgba(0, 212, 255, 0.35));
          transition: all 0.5s cubic-bezier(0.16, 1, 0.3, 1);
          /* GPU acceleration */
          transform: translateZ(0);
          -webkit-transform: translateZ(0);
          will-change: transform, filter;
          backface-visibility: hidden;
          -webkit-backface-visibility: hidden;
        }

        .whale-container:hover {
          transform: translate3d(0, -16px, 0) scale(1.08);
          filter: drop-shadow(0 24px 64px rgba(0, 212, 255, 0.5));
        }

        .whale-container:active {
          transform: translate3d(0, -12px, 0) scale(1.05);
          transition: all 0.15s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .whale-pulse {
          animation: smoothBreathe 4.5s ease-in-out infinite;
        }

        @keyframes smoothBreathe {
          0%, 100% { transform: translate3d(0, 0, 0) scale(1); }
          50% { transform: translate3d(0, -8px, 0) scale(1.03); }
        }

        .water-spout {
          animation: smoothSpray 2.8s ease-in-out infinite;
        }

        @keyframes smoothSpray {
          0%, 100% { opacity: 0.7; transform: translate3d(0, 0, 0); }
          50% { opacity: 1; transform: translate3d(0, -5px, 0); }
        }

        .captain-hat {
          animation: smoothTilt 3.8s ease-in-out infinite;
        }

        @keyframes smoothTilt {
          0%, 100% { transform: rotate(0deg); }
          50% { transform: rotate(6deg); }
        }

        .modal-overlay {
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.75);
          backdrop-filter: blur(20px);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 3000;
          animation: fadeIn 0.3s ease;
          padding: 24px;
          overflow-y: auto;
        }

        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }

        .quote-overlay {
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.75);
          backdrop-filter: blur(20px);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 3000;
          animation: fadeIn 0.3s ease;
          padding: 24px;
        }

        .quote-modal, .paywall-modal, .lesson-modal, .new-post-modal {
          background: rgba(255, 255, 255, 0.08);
          backdrop-filter: blur(80px) saturate(200%);
          border: 1px solid rgba(255, 255, 255, 0.15);
          border-radius: 28px;
          padding: 48px 36px;
          max-width: 580px;
          width: 100%;
          animation: scaleIn 0.4s cubic-bezier(0.4, 0, 0.2, 1);
          box-shadow: 0 32px 80px rgba(0, 0, 0, 0.4);
          position: relative;
        }

        .lesson-modal {
          max-width: 720px;
          max-height: 90vh;
          overflow-y: auto;
          padding: 32px 28px;
        }

        .new-post-modal {
          max-width: 500px;
          padding: 28px 24px;
        }

        @keyframes scaleIn {
          from { 
            opacity: 0; 
            transform: scale(0.9) translateY(24px);
          }
          to { 
            opacity: 1; 
            transform: scale(1) translateY(0);
          }
        }

        .modal-close {
          position: absolute;
          top: 20px;
          right: 20px;
          background: rgba(255, 255, 255, 0.1);
          border: none;
          border-radius: 50%;
          width: 40px;
          height: 40px;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          color: #fff;
          transition: all 0.2s ease;
        }

        .modal-close:hover {
          background: rgba(255, 255, 255, 0.2);
        }

        .quote-whale {
          font-size: 64px;
          margin-bottom: 28px;
          animation: bob 2s ease-in-out infinite;
        }

        @keyframes bob {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-10px); }
        }

        .quote-text {
          font-size: 22px;
          font-weight: 500;
          line-height: 1.6;
          margin-bottom: 24px;
          letter-spacing: -0.01em;
        }

        .quote-source {
          font-size: 15px;
          font-weight: 600;
          color: #00d4ff;
          margin-bottom: 36px;
        }

        .quote-btn, .subscribe-btn {
          background: linear-gradient(135deg, #00d4ff 0%, #40dfff 100%);
          color: #000;
          border: none;
          border-radius: 14px;
          padding: 16px 36px;
          font-weight: 600;
          font-size: 17px;
          cursor: pointer;
          transition: all 0.3s ease;
          box-shadow: 0 6px 20px rgba(0, 212, 255, 0.35);
          width: 100%;
        }

        .quote-btn:hover, .subscribe-btn:hover {
          transform: scale(1.02);
          box-shadow: 0 10px 32px rgba(0, 212, 255, 0.5);
        }

        .hero {
          text-align: center;
          margin-bottom: 48px;
        }

        .hero-title {
          font-size: clamp(34px, 6vw, 52px);
          font-weight: 700;
          background: linear-gradient(135deg, #fff 0%, #00d4ff 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          margin-bottom: 12px;
          letter-spacing: -0.03em;
        }

        .hero-subtitle {
          color: rgba(255, 255, 255, 0.65);
          font-size: 18px;
          font-weight: 400;
        }

        .stats-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 12px;
          margin-bottom: 32px;
        }

        .stat-card {
          text-align: center;
          padding: 28px 16px;
          background: rgba(255, 255, 255, 0.06);
          border: 0.5px solid rgba(255, 255, 255, 0.12);
        }

        .stat-card:hover {
          background: rgba(255, 255, 255, 0.09);
          transform: translateY(-8px);
        }

        .stat-icon {
          font-size: 40px;
          margin-bottom: 14px;
        }

        .stat-value {
          font-size: 32px;
          font-weight: 700;
          margin-bottom: 8px;
          letter-spacing: -0.02em;
        }

        .stat-label {
          font-size: 12px;
          color: rgba(255, 255, 255, 0.5);
          text-transform: uppercase;
          letter-spacing: 0.06em;
          font-weight: 500;
        }

        .section-title {
          font-size: 20px;
          font-weight: 600;
          margin-bottom: 20px;
          letter-spacing: -0.01em;
        }

        .action-list {
          display: flex;
          flex-direction: column;
          gap: 10px;
        }

        .action-item {
          display: flex;
          align-items: center;
          gap: 16px;
          padding: 18px;
          background: rgba(255, 255, 255, 0.04);
          border: 0.5px solid rgba(255, 255, 255, 0.08);
          border-radius: 16px;
          cursor: pointer;
          transition: all 0.3s ease;
        }

        .action-item:hover {
          background: rgba(255, 255, 255, 0.08);
          border-color: rgba(255, 255, 255, 0.15);
          transform: translateX(4px);
        }

        .action-icon {
          font-size: 28px;
        }

        .action-content {
          flex: 1;
        }

        .action-name {
          font-weight: 600;
          font-size: 16px;
          margin-bottom: 4px;
        }

        .action-desc {
          font-size: 14px;
          color: rgba(255, 255, 255, 0.5);
        }

        .action-arrow {
          color: #00d4ff;
          transition: transform 0.3s ease;
        }

        .action-item:hover .action-arrow {
          transform: translateX(4px);
        }

        .premium-banner {
          display: flex;
          align-items: center;
          gap: 18px;
          cursor: pointer;
          background: linear-gradient(135deg, rgba(255, 215, 0, 0.1) 0%, rgba(0, 212, 255, 0.08) 100%);
          border: 0.5px solid rgba(255, 215, 0, 0.2);
        }

        .premium-banner:hover {
          border-color: rgba(255, 215, 0, 0.3);
        }

        .banner-content {
          flex: 1;
        }

        .banner-title {
          font-weight: 600;
          font-size: 17px;
          color: #ffd700;
          margin-bottom: 6px;
        }

        .banner-subtitle {
          font-size: 14px;
          color: rgba(255, 255, 255, 0.6);
        }

        .banner-arrow {
          color: #ffd700;
        }

        .page-header {
          text-align: center;
          margin-bottom: 32px;
        }

        .page-title {
          font-size: 36px;
          font-weight: 700;
          margin-bottom: 10px;
          letter-spacing: -0.02em;
        }

        .page-subtitle {
          color: rgba(255, 255, 255, 0.65);
          font-size: 17px;
        }

        .wordle-grid {
          display: flex;
          flex-direction: column;
          gap: 10px;
          margin-bottom: 28px;
        }

        .wordle-row {
          display: flex;
          gap: 10px;
          justify-content: center;
        }

        .wordle-tile {
          width: 56px;
          height: 56px;
          border: 1.5px solid rgba(255, 255, 255, 0.15);
          border-radius: 12px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 28px;
          font-weight: 700;
          background: rgba(255, 255, 255, 0.02);
          transition: all 0.3s ease;
        }

        .wordle-tile.correct {
          background: #00d4ff;
          border-color: #00d4ff;
          color: #000;
          box-shadow: 0 0 24px rgba(0, 212, 255, 0.5);
          transform: scale(1.05);
        }

        .wordle-tile.present {
          background: #ff6b9d;
          border-color: #ff6b9d;
          color: #fff;
          box-shadow: 0 0 24px rgba(255, 107, 157, 0.5);
          transform: scale(1.05);
        }

        .wordle-tile.absent {
          background: rgba(255, 255, 255, 0.05);
          border-color: rgba(255, 255, 255, 0.08);
          color: rgba(255, 255, 255, 0.3);
        }

        .keyboard {
          display: flex;
          flex-direction: column;
          gap: 8px;
          margin-top: 24px;
        }

        .keyboard-row {
          display: flex;
          gap: 6px;
          justify-content: center;
        }

        .key {
          background: rgba(255, 255, 255, 0.1);
          border: 0.5px solid rgba(255, 255, 255, 0.15);
          border-radius: 8px;
          padding: 14px;
          min-width: 40px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s ease;
          color: #fff;
          font-size: 14px;
        }

        .key:hover:not(:disabled) {
          background: rgba(255, 255, 255, 0.15);
          transform: scale(1.05);
        }

        .key:active:not(:disabled) {
          transform: scale(0.95);
        }

        .key:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }

        .key.key-wide {
          padding: 14px 20px;
          font-size: 12px;
        }

        .key.correct {
          background: #00d4ff;
          border-color: #00d4ff;
          color: #000;
        }

        .key.present {
          background: #ff6b9d;
          border-color: #ff6b9d;
          color: #fff;
        }

        .key.absent {
          background: rgba(255, 255, 255, 0.05);
          border-color: rgba(255, 255, 255, 0.05);
          color: rgba(255, 255, 255, 0.3);
        }

        .win-message, .loss-message {
          text-align: center;
          padding: 28px;
          background: rgba(0, 212, 255, 0.1);
          border-radius: 16px;
          border: 1px solid rgba(0, 212, 255, 0.2);
          margin-top: 20px;
        }

        .loss-message {
          background: rgba(255, 107, 157, 0.1);
          border-color: rgba(255, 107, 157, 0.2);
        }

        .win-icon {
          color: #00d4ff;
          margin-bottom: 12px;
        }

        .win-text, .loss-text {
          font-size: 18px;
          font-weight: 600;
          color: #00d4ff;
          margin-bottom: 12px;
        }

        .loss-text {
          color: #ff6b9d;
        }

        .win-definition {
          font-size: 14px;
          color: rgba(255, 255, 255, 0.7);
          margin-top: 12px;
        }

        .loss-subtext {
          font-size: 14px;
          color: rgba(255, 255, 255, 0.6);
        }

        .progress-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 16px;
        }

        .progress-label {
          font-size: 14px;
          color: rgba(255, 255, 255, 0.5);
          text-transform: uppercase;
          letter-spacing: 0.08em;
        }

        .progress-value {
          font-size: 24px;
          font-weight: 700;
          color: #00d4ff;
        }

        .xp-bar {
          height: 8px;
          background: rgba(255, 255, 255, 0.1);
          border-radius: 4px;
          overflow: hidden;
          margin-bottom: 8px;
        }

        .xp-fill {
          height: 100%;
          background: linear-gradient(90deg, #00d4ff 0%, #40dfff 100%);
          transition: width 0.5s ease;
          box-shadow: 0 0 16px rgba(0, 212, 255, 0.5);
        }

        .xp-subtext {
          font-size: 12px;
          color: rgba(255, 255, 255, 0.5);
          text-align: right;
        }

        .lessons-list {
          display: flex;
          flex-direction: column;
          gap: 16px;
        }

        .lesson-card {
          padding: 24px;
          cursor: pointer;
          position: relative;
        }

        .premium-badge {
          position: absolute;
          top: 16px;
          right: 16px;
          background: rgba(255, 215, 0, 0.2);
          border: 1px solid rgba(255, 215, 0, 0.3);
          border-radius: 12px;
          padding: 6px 12px;
          font-size: 11px;
          font-weight: 600;
          color: #ffd700;
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .lesson-card-header {
          display: flex;
          gap: 16px;
          margin-bottom: 16px;
        }

        .lesson-icon {
          font-size: 52px;
        }

        .lesson-info {
          flex: 1;
        }

        .lesson-title {
          font-size: 20px;
          font-weight: 700;
          margin-bottom: 8px;
        }

        .lesson-meta {
          font-size: 13px;
          color: rgba(255, 255, 255, 0.5);
        }

        .lesson-desc {
          margin-bottom: 20px;
          line-height: 1.6;
          color: rgba(255, 255, 255, 0.7);
        }

        .lesson-footer {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding-top: 20px;
          border-top: 1px solid rgba(255, 255, 255, 0.08);
        }

        .lesson-reward {
          display: flex;
          align-items: center;
          gap: 6px;
          color: #ffd700;
          font-weight: 600;
        }

        .lesson-arrow {
          color: #00d4ff;
        }

        .market-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 12px;
        }

        .market-item {
          padding: 16px;
          background: rgba(255, 255, 255, 0.03);
          border: 0.5px solid rgba(255, 255, 255, 0.08);
          border-radius: 14px;
        }

        .market-symbol {
          font-weight: 700;
          font-size: 16px;
          margin-bottom: 4px;
        }

        .market-name {
          font-size: 12px;
          color: rgba(255, 255, 255, 0.5);
          margin-bottom: 12px;
        }

        .market-price {
          font-size: 20px;
          font-weight: 700;
          margin-bottom: 6px;
        }

        .market-change {
          font-size: 13px;
          font-weight: 600;
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .market-change.up {
          color: #00ff88;
        }

        .market-change.down {
          color: #ff6b9d;
        }

        .news-list {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }

        .news-item {
          display: flex;
          gap: 16px;
          padding: 16px;
          background: rgba(255, 255, 255, 0.03);
          border: 0.5px solid rgba(255, 255, 255, 0.08);
          border-radius: 14px;
          cursor: pointer;
          transition: all 0.3s ease;
        }

        .news-item:hover {
          background: rgba(255, 255, 255, 0.06);
          border-color: rgba(255, 255, 255, 0.15);
          transform: translateX(4px);
        }

        .news-icon {
          font-size: 32px;
          flex-shrink: 0;
        }

        .news-content {
          flex: 1;
        }

        .news-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 8px;
        }

        .news-source {
          font-size: 12px;
          font-weight: 600;
          color: #00d4ff;
        }

        .news-time {
          font-size: 12px;
          color: rgba(255, 255, 255, 0.4);
        }

        .news-title {
          font-weight: 600;
          font-size: 16px;
          margin-bottom: 8px;
          line-height: 1.3;
        }

        .news-summary {
          font-size: 14px;
          color: rgba(255, 255, 255, 0.65);
          line-height: 1.5;
          margin-bottom: 8px;
        }

        .news-category {
          display: inline-block;
          font-size: 11px;
          color: #00d4ff;
          background: rgba(0, 212, 255, 0.1);
          padding: 4px 10px;
          border-radius: 8px;
          font-weight: 600;
        }

        .news-link-icon {
          color: rgba(255, 255, 255, 0.3);
          flex-shrink: 0;
        }

        .new-post-btn {
          width: 100%;
          padding: 18px 24px;
          background: rgba(0, 212, 255, 0.08);
          border: 1px solid rgba(0, 212, 255, 0.2);
          border-radius: 16px;
          color: rgba(255, 255, 255, 0.6);
          font-size: 16px;
          cursor: pointer;
          transition: all 0.3s ease;
          display: flex;
          align-items: center;
          gap: 12px;
          margin-bottom: 24px;
        }

        .new-post-btn:hover {
          background: rgba(0, 212, 255, 0.12);
          border-color: rgba(0, 212, 255, 0.3);
        }

        .new-post-icon {
          font-size: 24px;
        }

        .posts-list {
          display: flex;
          flex-direction: column;
          gap: 16px;
        }

        .post-card {
          padding: 24px;
        }

        .post-header {
          margin-bottom: 16px;
        }

        .post-author {
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .post-avatar {
          font-size: 32px;
        }

        .post-author-info {
          flex: 1;
        }

        .post-author-name {
          font-weight: 600;
          font-size: 16px;
          margin-bottom: 4px;
        }

        .post-meta {
          font-size: 13px;
          color: rgba(255, 255, 255, 0.5);
        }

        .post-rank {
          color: #00d4ff;
          font-weight: 600;
        }

        .post-content {
          font-size: 15px;
          line-height: 1.6;
          color: rgba(255, 255, 255, 0.85);
          margin-bottom: 16px;
        }

        .post-actions {
          display: flex;
          gap: 8px;
          padding-top: 16px;
          border-top: 1px solid rgba(255, 255, 255, 0.08);
        }

        .post-action {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 8px 16px;
          background: rgba(255, 255, 255, 0.04);
          border: 0.5px solid rgba(255, 255, 255, 0.08);
          border-radius: 10px;
          color: rgba(255, 255, 255, 0.6);
          font-size: 14px;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .post-action:hover {
          background: rgba(255, 255, 255, 0.08);
          border-color: rgba(255, 255, 255, 0.15);
        }

        .post-action.active {
          background: rgba(0, 212, 255, 0.15);
          border-color: rgba(0, 212, 255, 0.3);
          color: #00d4ff;
        }

        .replies-list {
          margin-top: 16px;
          padding-left: 20px;
          border-left: 2px solid rgba(255, 255, 255, 0.08);
        }

        .reply-item {
          margin-top: 12px;
          padding: 12px;
          background: rgba(255, 255, 255, 0.02);
          border-radius: 12px;
        }

        .reply-header {
          display: flex;
          align-items: center;
          gap: 8px;
          margin-bottom: 8px;
        }

        .reply-avatar {
          font-size: 20px;
        }

        .reply-author-info {
          display: flex;
          gap: 8px;
          align-items: center;
          font-size: 13px;
        }

        .reply-author {
          font-weight: 600;
        }

        .reply-meta {
          color: rgba(255, 255, 255, 0.4);
        }

        .reply-content {
          font-size: 14px;
          line-height: 1.5;
          color: rgba(255, 255, 255, 0.8);
          margin-bottom: 8px;
        }

        .reply-actions {
          display: flex;
          gap: 8px;
        }

        .reply-action {
          display: flex;
          align-items: center;
          gap: 4px;
          padding: 4px 10px;
          background: rgba(255, 255, 255, 0.04);
          border: 0.5px solid rgba(255, 255, 255, 0.06);
          border-radius: 8px;
          color: rgba(255, 255, 255, 0.5);
          font-size: 12px;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .reply-action:hover {
          background: rgba(255, 255, 255, 0.06);
        }

        .reply-action.active {
          background: rgba(0, 212, 255, 0.12);
          border-color: rgba(0, 212, 255, 0.2);
          color: #00d4ff;
        }

        .reply-input-section {
          display: flex;
          gap: 8px;
          margin-top: 12px;
          padding: 12px;
          background: rgba(255, 255, 255, 0.02);
          border-radius: 12px;
        }

        .reply-input {
          flex: 1;
          background: rgba(255, 255, 255, 0.04);
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 10px;
          padding: 10px 14px;
          color: #fff;
          font-size: 14px;
        }

        .reply-input:focus {
          outline: none;
          border-color: #00d4ff;
          background: rgba(255, 255, 255, 0.06);
        }

        .reply-send-btn {
          background: linear-gradient(135deg, #00d4ff 0%, #40dfff 100%);
          color: #000;
          border: none;
          border-radius: 10px;
          padding: 10px 16px;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .reply-send-btn:hover {
          transform: scale(1.05);
        }

        .paywall-header {
          text-align: center;
          margin-bottom: 32px;
        }

        .paywall-icon {
          color: #ffd700;
          margin-bottom: 20px;
          animation: bob 2s ease-in-out infinite;
        }

        .paywall-title {
          font-size: 32px;
          font-weight: 700;
          margin-bottom: 12px;
        }

        .paywall-subtitle {
          font-size: 16px;
          color: rgba(255, 255, 255, 0.65);
        }

        .plan-selector {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 12px;
          margin-bottom: 32px;
        }

        .plan-option {
          padding: 24px 20px;
          background: rgba(255, 255, 255, 0.04);
          border: 1.5px solid rgba(255, 255, 255, 0.1);
          border-radius: 16px;
          cursor: pointer;
          transition: all 0.3s ease;
          text-align: center;
          position: relative;
        }

        .plan-option:hover {
          background: rgba(255, 255, 255, 0.06);
          border-color: rgba(255, 255, 255, 0.15);
        }

        .plan-option.active {
          background: rgba(0, 212, 255, 0.1);
          border-color: #00d4ff;
        }

        .plan-badge {
          position: absolute;
          top: -10px;
          left: 50%;
          transform: translateX(-50%);
          background: #ffd700;
          color: #000;
          padding: 4px 12px;
          border-radius: 12px;
          font-size: 10px;
          font-weight: 700;
          letter-spacing: 0.05em;
        }

        .plan-period {
          font-size: 14px;
          color: rgba(255, 255, 255, 0.6);
          margin-bottom: 8px;
        }

        .plan-price {
          font-size: 36px;
          font-weight: 700;
          margin-bottom: 4px;
        }

        .plan-label {
          font-size: 13px;
          color: rgba(255, 255, 255, 0.5);
          margin-bottom: 8px;
        }

        .plan-savings {
          font-size: 12px;
          color: #00ff88;
          font-weight: 600;
        }

        .features-list {
          margin-bottom: 28px;
        }

        .feature-item {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 12px 0;
          border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }

        .feature-icon {
          color: #00d4ff;
          flex-shrink: 0;
        }

        .premium-tools-preview {
          margin-bottom: 28px;
          padding: 20px;
          background: rgba(255, 255, 255, 0.03);
          border-radius: 16px;
        }

        .tools-title {
          font-size: 16px;
          font-weight: 600;
          margin-bottom: 16px;
        }

        .tools-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 12px;
        }

        .tool-card {
          text-align: center;
          padding: 16px;
          background: rgba(255, 255, 255, 0.04);
          border: 0.5px solid rgba(255, 255, 255, 0.08);
          border-radius: 12px;
        }

        .tool-icon {
          font-size: 36px;
          margin-bottom: 8px;
        }

        .tool-name {
          font-size: 13px;
          font-weight: 500;
        }

        .tool-item {
          text-align: center;
          padding: 20px;
          background: rgba(255, 255, 255, 0.04);
          border: 0.5px solid rgba(255, 255, 255, 0.08);
          border-radius: 14px;
          cursor: pointer;
          transition: all 0.3s ease;
        }

        .tool-item:hover {
          background: rgba(255, 255, 255, 0.06);
          transform: translateY(-4px);
        }

        .tool-icon-large {
          font-size: 40px;
          margin-bottom: 12px;
        }

        .tool-category {
          font-size: 11px;
          color: rgba(255, 255, 255, 0.4);
          text-transform: uppercase;
          letter-spacing: 0.05em;
          margin-top: 6px;
        }

        .paywall-disclaimer {
          text-align: center;
          font-size: 13px;
          color: rgba(255, 255, 255, 0.5);
          margin-top: 20px;
        }

        .lesson-header {
          text-align: center;
          margin-bottom: 24px;
        }

        .lesson-progress-bar {
          height: 6px;
          background: rgba(255, 255, 255, 0.1);
          border-radius: 3px;
          overflow: hidden;
          margin-bottom: 24px;
        }

        .lesson-progress-fill {
          height: 100%;
          background: linear-gradient(90deg, #00d4ff 0%, #40dfff 100%);
          transition: width 0.3s ease;
        }

        .lesson-video {
          margin-bottom: 28px;
        }

        .video-placeholder {
          background: rgba(255, 255, 255, 0.04);
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 16px;
          padding: 60px 20px;
          text-align: center;
          cursor: pointer;
          transition: all 0.3s ease;
        }

        .video-placeholder:hover {
          background: rgba(255, 255, 255, 0.06);
          border-color: rgba(255, 255, 255, 0.15);
        }

        .play-icon {
          color: #00d4ff;
          margin-bottom: 12px;
        }

        .video-label {
          font-size: 16px;
          font-weight: 600;
          margin-bottom: 8px;
        }

        .video-link {
          font-size: 14px;
          color: rgba(255, 255, 255, 0.5);
        }

        .lesson-content {
          margin-bottom: 28px;
        }

        .section-content {
          font-size: 15px;
          line-height: 1.7;
          color: rgba(255, 255, 255, 0.8);
          margin-bottom: 20px;
        }

        .key-points {
          background: rgba(0, 212, 255, 0.05);
          border: 1px solid rgba(0, 212, 255, 0.15);
          border-radius: 12px;
          padding: 20px;
          margin-bottom: 20px;
        }

        .key-points-title {
          font-size: 14px;
          font-weight: 600;
          color: #00d4ff;
          margin-bottom: 12px;
        }

        .key-points-list {
          list-style: none;
          padding: 0;
        }

        .key-points-list li {
          font-size: 14px;
          line-height: 1.6;
          color: rgba(255, 255, 255, 0.7);
          margin-bottom: 8px;
          padding-left: 20px;
          position: relative;
        }

        .key-points-list li::before {
          content: '→';
          position: absolute;
          left: 0;
          color: #00d4ff;
        }

        .template-btn {
          background: rgba(0, 212, 255, 0.1);
          border: 1px solid rgba(0, 212, 255, 0.2);
          border-radius: 12px;
          padding: 12px 20px;
          color: #00d4ff;
          font-weight: 600;
          cursor: pointer;
          display: flex;
          align-items: center;
          gap: 8px;
          justify-content: center;
          transition: all 0.3s ease;
        }

        .template-btn:hover {
          background: rgba(0, 212, 255, 0.15);
          border-color: rgba(0, 212, 255, 0.3);
        }

        .lesson-nav {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding-top: 24px;
          border-top: 1px solid rgba(255, 255, 255, 0.08);
        }

        .lesson-nav-btn {
          background: rgba(255, 255, 255, 0.08);
          border: 1px solid rgba(255, 255, 255, 0.12);
          border-radius: 12px;
          padding: 12px 24px;
          color: #fff;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.3s ease;
        }

        .lesson-nav-btn:hover:not(:disabled) {
          background: rgba(255, 255, 255, 0.12);
        }

        .lesson-nav-btn:disabled {
          opacity: 0.3;
          cursor: not-allowed;
        }

        .lesson-nav-btn.primary {
          background: linear-gradient(135deg, #00d4ff 0%, #40dfff 100%);
          color: #000;
          border: none;
        }

        .lesson-nav-btn.primary:hover {
          transform: scale(1.05);
        }

        .lesson-counter {
          font-size: 14px;
          color: rgba(255, 255, 255, 0.5);
        }

        .modal-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 24px;
        }

        .modal-title {
          font-size: 20px;
          font-weight: 700;
        }

        .post-textarea {
          width: 100%;
          background: rgba(255, 255, 255, 0.04);
          border: 1.5px solid rgba(255, 255, 255, 0.12);
          border-radius: 14px;
          padding: 16px;
          color: #fff;
          font-size: 15px;
          font-family: inherit;
          resize: none;
          margin-bottom: 16px;
        }

        .post-textarea:focus {
          outline: none;
          border-color: #00d4ff;
          background: rgba(255, 255, 255, 0.06);
        }

        .post-actions {
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .character-count {
          font-size: 13px;
          color: rgba(255, 255, 255, 0.4);
        }

        .post-submit-btn {
          background: linear-gradient(135deg, #00d4ff 0%, #40dfff 100%);
          color: #000;
          border: none;
          border-radius: 12px;
          padding: 12px 24px;
          font-weight: 600;
          cursor: pointer;
          display: flex;
          align-items: center;
          gap: 8px;
          transition: all 0.3s ease;
        }

        .post-submit-btn:hover:not(:disabled) {
          transform: scale(1.05);
        }

        .post-submit-btn:disabled {
          opacity: 0.4;
          cursor: not-allowed;
        }

        .bottom-nav {
          position: fixed;
          bottom: 0;
          left: 0;
          right: 0;
          background: rgba(0, 21, 41, 0.85);
          backdrop-filter: blur(40px) saturate(180%);
          border-top: 0.5px solid rgba(255, 255, 255, 0.1);
          padding: 10px 0 max(10px, env(safe-area-inset-bottom));
          z-index: 1000;
          box-shadow: 0 -6px 28px rgba(0, 0, 0, 0.25);
        }

        .nav-container {
          display: flex;
          justify-content: space-around;
          max-width: 680px;
          margin: 0 auto;
          padding: 0 16px;
        }

        .nav-item {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 4px;
          padding: 8px 14px;
          cursor: pointer;
          transition: all 0.2s ease;
          border-radius: 12px;
          color: rgba(255, 255, 255, 0.4);
          position: relative;
        }

        .nav-item:active {
          transform: scale(0.95);
        }

        .nav-item.active {
          color: #00d4ff;
        }

        .nav-item.active::before {
          content: '';
          position: absolute;
          bottom: -6px;
          width: 5px;
          height: 5px;
          background: #00d4ff;
          border-radius: 50%;
        }

        .nav-label {
          font-size: 11px;
          font-weight: 600;
          letter-spacing: 0.02em;
        }

        @media (max-width: 480px) {
          .stats-grid {
            grid-template-columns: 1fr;
          }

          .plan-selector {
            grid-template-columns: 1fr;
          }

          .market-grid, .tools-grid {
            grid-template-columns: 1fr;
          }

          .keyboard-row {
            gap: 4px;
          }

          .key {
            min-width: 32px;
            padding: 12px 8px;
            font-size: 13px;
          }

          .wordle-tile {
            width: 48px;
            height: 48px;
            font-size: 24px;
          }
        }
      `}</style>

      {activeTab === 'home' && <HomeView />}
      {activeTab === 'vault' && <VaultView />}
      {activeTab === 'depths' && <DepthsView />}
      {activeTab === 'tides' && <TidesView />}
      {activeTab === 'reef' && <ReefView />}

      {showQuoteModal && <QuoteModal />}
      {showPaywall && <PaywallModal />}
      {showLessonModal && <LessonModal />}
      {showNewPostModal && <NewPostModal />}

      <div className="bottom-nav">
        <div className="nav-container">
          <div className={`nav-item ${activeTab === 'vault' ? 'active' : ''}`} onClick={() => {
            if (activeTab === 'vault') return;
            playSound('wave');
            setIsTransitioning(true);
            requestAnimationFrame(() => {
              setTimeout(() => {
                setActiveTab('vault');
                requestAnimationFrame(() => {
                  setIsTransitioning(false);
                });
              }, 350);
            });
          }}>
            <Target size={22} />
            <span className="nav-label">Vault</span>
          </div>
          <div className={`nav-item ${activeTab === 'depths' ? 'active' : ''}`} onClick={() => {
            if (activeTab === 'depths') return;
            playSound('wave');
            setIsTransitioning(true);
            requestAnimationFrame(() => {
              setTimeout(() => {
                setActiveTab('depths');
                requestAnimationFrame(() => {
                  setIsTransitioning(false);
                });
              }, 350);
            });
          }}>
            <Award size={22} />
            <span className="nav-label">Depths</span>
          </div>
          <div className={`nav-item ${activeTab === 'home' ? 'active' : ''}`} onClick={() => {
            if (activeTab === 'home') return;
            playSound('wave');
            setIsTransitioning(true);
            requestAnimationFrame(() => {
              setTimeout(() => {
                setActiveTab('home');
                requestAnimationFrame(() => {
                  setIsTransitioning(false);
                });
              }, 350);
            });
          }}>
            <Home size={22} />
            <span className="nav-label">Harbor</span>
          </div>
          <div className={`nav-item ${activeTab === 'reef' ? 'active' : ''}`} onClick={() => {
            if (activeTab === 'reef') return;
            playSound('wave');
            setIsTransitioning(true);
            requestAnimationFrame(() => {
              setTimeout(() => {
                setActiveTab('reef');
                requestAnimationFrame(() => {
                  setIsTransitioning(false);
                });
              }, 350);
            });
          }}>
            <Users size={22} />
            <span className="nav-label">Reef</span>
          </div>
          <div className={`nav-item ${activeTab === 'tides' ? 'active' : ''}`} onClick={() => {
            if (activeTab === 'tides') return;
            playSound('wave');
            setIsTransitioning(true);
            requestAnimationFrame(() => {
              setTimeout(() => {
                setActiveTab('tides');
                requestAnimationFrame(() => {
                  setIsTransitioning(false);
                });
              }, 350);
            });
          }}>
            <TrendingUp size={22} />
            <span className="nav-label">Tides</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LifeVest;
