import React, { useState, useEffect } from 'react';
import { Target, Award, Home, Users, TrendingUp, X, Crown, Lock, Calculator, Shield, ChevronRight, Sparkles, MessageCircle, Send, ThumbsUp, ThumbsDown, Play, Download } from 'lucide-react';

const LifeVest = () => {
  const [activeTab, setActiveTab] = useState('home');
  const [currentTier, setCurrentTier] = useState('free');
  const [selectedTier, setSelectedTier] = useState('sovereign');
  const [billingCycle, setBillingCycle] = useState('annual');
  const [showPaywall, setShowPaywall] = useState(false);
  const [dailyStreak, setDailyStreak] = useState(7);
  const [barnaclePoints, setBarnaclePoints] = useState(1250);
  const [knowledgeXP, setKnowledgeXP] = useState(350);
  
  // Vault game state
  const [currentGuess, setCurrentGuess] = useState('');
  const [guesses, setGuesses] = useState([]);
  const [gameWon, setGameWon] = useState(false);
  const todaysWord = 'YIELD';

  // Sound system
  const playSound = (type) => {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      
      const sounds = {
        wave: { freq: 200, decay: 0.5, vol: 0.1 },
        bubble: { freq: 800, decay: 0.1, vol: 0.15 },
        success: { freq: 523.25, decay: 0.3, vol: 0.2 }
      };
      
      const s = sounds[type] || sounds.bubble;
      osc.frequency.setValueAtTime(s.freq, ctx.currentTime);
      gain.gain.setValueAtTime(s.vol, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + s.decay);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + s.decay);
    } catch(e) {}
  };

  const handleKeyPress = (key) => {
    playSound('bubble');
    if (key === '←') {
      setCurrentGuess(currentGuess.slice(0, -1));
    } else if (key === 'ENTER') {
      if (currentGuess.length === 5) {
        const newGuesses = [...guesses, currentGuess.toUpperCase()];
        setGuesses(newGuesses);
        if (currentGuess.toUpperCase() === todaysWord) {
          setGameWon(true);
          setBarnaclePoints(barnaclePoints + 50);
          playSound('success');
        }
        setCurrentGuess('');
      }
    } else if (currentGuess.length < 5) {
      setCurrentGuess(currentGuess + key);
    }
  };

  const getTileColor = (letter, index, word) => {
    if (!word) return 'empty';
    if (todaysWord[index] === letter) return 'correct';
    if (todaysWord.includes(letter)) return 'present';
    return 'absent';
  };

  const subscriptionTiers = {
    voyager: {
      name: 'Voyager',
      icon: '⚓',
      price: { monthly: 9, annual: 89 },
      savings: 19,
      tagline: 'Start Your Journey',
      features: ['Autopilot Investing Lite', '10 Premium Courses', 'Basic Analytics', 'Community Access', '3 Investment Strategies', 'Monthly Market Insights', 'Debt Calculator']
    },
    sovereign: {
      name: 'Sovereign',
      icon: '👑',
      price: { monthly: 29, annual: 299 },
      savings: 49,
      tagline: 'Master Your Wealth',
      badge: 'BEST VALUE',
      features: ['Everything in Voyager', 'AI Financial Coach', 'Tax-Loss Harvesting', 'Portfolio X-Ray', 'Retirement Crystal Ball', '50+ Premium Courses', 'Whale Alerts', '20 Strategies', '12 Calculators', '1 Expert Session/Year', 'Priority Support', 'Document Vault']
    },
    platinum: {
      name: 'Platinum',
      icon: '💎',
      price: { monthly: 79, annual: 799 },
      savings: 149,
      tagline: 'Ultimate Command',
      badge: 'PREMIUM',
      features: ['Everything in Sovereign', 'Account Manager', 'Unlimited Strategies', 'Family Plan (4 members)', 'After-Hours Trading', 'Metal Card 3% Cash Back', 'Quarterly Calls', 'Custom Portfolio', 'Tax Session', 'Bill Negotiation', 'Airport Lounges', 'Platinum Pods', 'Early Access', 'Conference VIP']
    }
  };

  return (
    <div className="lifevest-app">
      <style>{\`
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Space+Mono:wght@400;700&display=swap');

        * { 
          margin: 0; 
          padding: 0; 
          box-sizing: border-box; 
        }

        body {
          font-family: 'Space Mono', monospace;
          -webkit-font-smoothing: antialiased;
          overflow-x: hidden;
        }

        .lifevest-app {
          min-height: 100vh;
          background: 
            radial-gradient(ellipse at 20% 10%, rgba(0, 245, 255, 0.15) 0%, transparent 50%),
            radial-gradient(ellipse at 80% 90%, rgba(0, 150, 255, 0.12) 0%, transparent 50%),
            linear-gradient(180deg, #001219 0%, #000000 50%, #000814 100%);
          color: #fff;
          padding-bottom: 100px;
          position: relative;
          overflow: hidden;
          transform: translateZ(0);
        }

        /* CAUSTIC LIGHT OVERLAY - The signature water refraction effect */
        .lifevest-app::before {
          content: '';
          position: fixed;
          inset: 0;
          background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.01 0.05' numOctaves='4' seed='2'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E");
          opacity: 0.15;
          mix-blend-mode: screen;
          animation: causticDrift 20s ease-in-out infinite alternate;
          pointer-events: none;
          z-index: 1;
        }

        @keyframes causticDrift {
          0% { transform: translate3d(0, 0, 0) scale(1); }
          100% { transform: translate3d(25px, -25px, 0) scale(1.05); }
        }

        /* FLOATING PARTICLES - Marine snow effect */
        .particles {
          position: fixed;
          inset: 0;
          pointer-events: none;
          z-index: 2;
        }

        .particle {
          position: absolute;
          width: 3px;
          height: 3px;
          background: rgba(255, 255, 255, 0.4);
          border-radius: 50%;
          animation: float-down linear infinite;
        }

        @keyframes float-down {
          0% { 
            transform: translate3d(0, -20px, 0);
            opacity: 0;
          }
          10% { opacity: 0.8; }
          90% { opacity: 0.3; }
          100% { 
            transform: translate3d(20px, 100vh, 0);
            opacity: 0;
          }
        }

        /* RISING BUBBLES - From glass cards */
        .bubble {
          position: absolute;
          bottom: 0;
          width: 8px;
          height: 8px;
          background: radial-gradient(circle at 30% 30%, rgba(255, 255, 255, 0.8), rgba(0, 245, 255, 0.3));
          border-radius: 50%;
          animation: rise linear infinite;
        }

        @keyframes rise {
          0% { 
            transform: translate3d(0, 0, 0) scale(0.5);
            opacity: 0;
          }
          10% { opacity: 0.8; }
          90% { opacity: 0.4; }
          100% { 
            transform: translate3d(calc(var(--drift) * 1px), -100vh, 0) scale(1.2);
            opacity: 0;
          }
        }

        /* GLASSMORPHISM - Ultra-premium glass cards */
        .glass-card {
          background: rgba(255, 255, 255, 0.05);
          backdrop-filter: blur(60px) saturate(200%);
          -webkit-backdrop-filter: blur(60px) saturate(200%);
          border: 0.5px solid rgba(255, 255, 255, 0.1);
          border-radius: 24px;
          padding: 24px;
          margin-bottom: 16px;
          transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
          box-shadow: 
            0 8px 32px rgba(0, 0, 0, 0.3),
            inset 0 1px 0 rgba(255, 255, 255, 0.1);
          position: relative;
          overflow: hidden;
          transform: translateZ(0);
          will-change: transform;
        }

        .glass-card::before {
          content: '';
          position: absolute;
          top: 0;
          left: -100%;
          width: 100%;
          height: 100%;
          background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.1), transparent);
          transition: left 0.5s;
        }

        .glass-card:hover::before {
          left: 100%;
        }

        .glass-card:hover {
          transform: translate3d(0, -8px, 0);
          box-shadow: 
            0 16px 48px rgba(0, 245, 255, 0.2),
            inset 0 1px 0 rgba(255, 255, 255, 0.2);
          border-color: rgba(0, 245, 255, 0.3);
        }

        /* BIOLUMINESCENT GLOW - On interactive elements */
        .bio-glow {
          box-shadow: 0 0 20px rgba(0, 245, 255, 0.4);
          border-color: rgba(0, 245, 255, 0.6);
        }

        .gold-glow {
          box-shadow: 0 0 30px rgba(255, 215, 0, 0.5);
          border-color: rgba(255, 215, 0, 0.8);
        }

        /* VIEW CONTAINER - Smooth page transitions */
        .view-container {
          padding: 32px 20px;
          max-width: 680px;
          margin: 0 auto;
          position: relative;
          z-index: 10;
          transform: translateZ(0);
          animation: pageSlideIn 0.6s cubic-bezier(0.16, 1, 0.3, 1);
        }

        @keyframes pageSlideIn {
          0% { 
            opacity: 0; 
            transform: translate3d(0, 40px, 0) scale(0.95);
          }
          100% { 
            opacity: 1; 
            transform: translate3d(0, 0, 0) scale(1);
          }
        }

        /* FINN THE WHALE - Mascot with breathing animation */
        .finn-whale {
          font-size: 80px;
          text-align: center;
          margin: 24px 0;
          animation: breathe 4.5s ease-in-out infinite;
          cursor: pointer;
          transition: all 0.5s cubic-bezier(0.16, 1, 0.3, 1);
          filter: drop-shadow(0 12px 40px rgba(0, 245, 255, 0.4));
        }

        .finn-whale:hover {
          transform: translate3d(0, -16px, 0) scale(1.1);
          filter: drop-shadow(0 24px 60px rgba(0, 245, 255, 0.6));
        }

        @keyframes breathe {
          0%, 100% { transform: translate3d(0, 0, 0) scale(1); }
          50% { transform: translate3d(0, -10px, 0) scale(1.03); }
        }

        /* HERO SECTION */
        .hero-title {
          font-family: 'Orbitron', sans-serif;
          font-size: clamp(36px, 7vw, 56px);
          font-weight: 900;
          text-align: center;
          background: linear-gradient(135deg, #ffffff 0%, #00F5FF 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          margin-bottom: 12px;
          letter-spacing: -0.03em;
        }

        .hero-subtitle {
          text-align: center;
          color: rgba(255, 255, 255, 0.7);
          font-size: 16px;
          margin-bottom: 40px;
        }

        /* STATS GRID */
        .stats-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 12px;
          margin-bottom: 32px;
        }

        .stat-card {
          text-align: center;
          padding: 28px 20px;
          background: rgba(255, 255, 255, 0.04);
          backdrop-filter: blur(40px);
          border: 0.5px solid rgba(255, 255, 255, 0.12);
          border-radius: 20px;
          transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
          animation: cardFloat 6s ease-in-out infinite;
        }

        .stat-card:nth-child(1) { animation-delay: 0s; }
        .stat-card:nth-child(2) { animation-delay: 0.3s; }
        .stat-card:nth-child(3) { animation-delay: 0.6s; }

        @keyframes cardFloat {
          0%, 100% { transform: translate3d(0, 0, 0); }
          50% { transform: translate3d(0, -10px, 0); }
        }

        .stat-card:hover {
          transform: translate3d(0, -12px, 0);
          box-shadow: 0 16px 48px rgba(0, 245, 255, 0.25);
          border-color: rgba(0, 245, 255, 0.4);
        }

        .stat-icon {
          font-size: 44px;
          margin-bottom: 12px;
        }

        .stat-value {
          font-size: 36px;
          font-weight: 700;
          margin-bottom: 8px;
          font-family: 'Orbitron', sans-serif;
        }

        .stat-label {
          font-size: 11px;
          color: rgba(255, 255, 255, 0.5);
          text-transform: uppercase;
          letter-spacing: 0.1em;
        }

        /* WORDLE GRID - THE VAULT */
        .wordle-grid {
          display: grid;
          gap: 8px;
          max-width: 350px;
          margin: 0 auto 32px;
        }

        .wordle-row {
          display: grid;
          grid-template-columns: repeat(5, 1fr);
          gap: 8px;
        }

        .wordle-tile {
          aspect-ratio: 1;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 28px;
          font-weight: 700;
          font-family: 'Orbitron', sans-serif;
          background: rgba(255, 255, 255, 0.05);
          border: 2px solid rgba(255, 255, 255, 0.15);
          border-radius: 12px;
          backdrop-filter: blur(20px);
          transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
        }

        .wordle-tile.correct {
          background: rgba(0, 245, 255, 0.2);
          border-color: #00F5FF;
          box-shadow: 0 0 20px rgba(0, 245, 255, 0.6);
          transform: scale(1.05);
        }

        .wordle-tile.present {
          background: rgba(255, 215, 0, 0.2);
          border-color: #FFD700;
          box-shadow: 0 0 20px rgba(255, 215, 0, 0.5);
          transform: scale(1.05);
        }

        .wordle-tile.absent {
          background: rgba(255, 255, 255, 0.02);
          border-color: rgba(255, 255, 255, 0.08);
          opacity: 0.5;
        }

        /* ON-SCREEN KEYBOARD */
        .keyboard {
          display: flex;
          flex-direction: column;
          gap: 8px;
          max-width: 500px;
          margin: 0 auto;
        }

        .keyboard-row {
          display: flex;
          gap: 6px;
          justify-content: center;
        }

        .key {
          min-width: 40px;
          padding: 16px 12px;
          background: rgba(255, 255, 255, 0.08);
          border: 1px solid rgba(255, 255, 255, 0.15);
          border-radius: 8px;
          color: #fff;
          font-weight: 600;
          font-size: 14px;
          cursor: pointer;
          transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
          backdrop-filter: blur(20px);
        }

        .key:hover {
          background: rgba(255, 255, 255, 0.15);
          transform: translate3d(0, -2px, 0);
          box-shadow: 0 4px 12px rgba(0, 245, 255, 0.3);
        }

        .key:active {
          transform: scale(0.95);
        }

        .key.key-wide {
          padding: 16px 20px;
          font-size: 12px;
        }

        /* PREMIUM BANNER */
        .premium-banner {
          display: flex;
          align-items: center;
          gap: 16px;
          padding: 24px;
          background: linear-gradient(135deg, rgba(255, 215, 0, 0.15) 0%, rgba(0, 245, 255, 0.1) 100%);
          border: 1px solid rgba(255, 215, 0, 0.3);
          border-radius: 24px;
          margin-bottom: 24px;
          cursor: pointer;
          transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
          backdrop-filter: blur(40px);
        }

        .premium-banner:hover {
          transform: translate3d(0, -6px, 0);
          box-shadow: 0 16px 48px rgba(255, 215, 0, 0.3);
          border-color: rgba(255, 215, 0, 0.5);
        }

        /* MODAL OVERLAY */
        .modal-overlay {
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.85);
          backdrop-filter: blur(30px);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 3000;
          padding: 24px;
          overflow-y: auto;
          animation: fadeIn 0.3s ease;
        }

        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }

        .paywall-modal {
          background: rgba(0, 18, 25, 0.95);
          backdrop-filter: blur(80px) saturate(180%);
          border: 1px solid rgba(0, 245, 255, 0.2);
          border-radius: 32px;
          padding: 48px 36px;
          max-width: 1100px;
          width: 100%;
          position: relative;
          animation: slideUp 0.5s cubic-bezier(0.16, 1, 0.3, 1);
          box-shadow: 0 32px 80px rgba(0, 0, 0, 0.6);
        }

        @keyframes slideUp {
          from { 
            opacity: 0;
            transform: translate3d(0, 40px, 0) scale(0.95);
          }
          to { 
            opacity: 1;
            transform: translate3d(0, 0, 0) scale(1);
          }
        }

        .modal-close {
          position: absolute;
          top: 20px;
          right: 20px;
          background: rgba(255, 255, 255, 0.1);
          border: none;
          border-radius: 50%;
          width: 44px;
          height: 44px;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          color: #fff;
          transition: all 0.3s ease;
        }

        .modal-close:hover {
          background: rgba(255, 255, 255, 0.2);
          transform: rotate(90deg);
        }

        /* TIER CARDS */
        .tiers-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 20px;
          margin: 32px 0;
        }

        .tier-card {
          background: rgba(255, 255, 255, 0.04);
          border: 2px solid rgba(255, 255, 255, 0.1);
          border-radius: 28px;
          padding: 32px 24px;
          cursor: pointer;
          transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
          position: relative;
          backdrop-filter: blur(60px);
        }

        .tier-card:hover {
          transform: translate3d(0, -12px, 0);
          box-shadow: 0 20px 60px rgba(0, 245, 255, 0.3);
        }

        .tier-card.selected {
          border-color: #00F5FF;
          background: rgba(0, 245, 255, 0.08);
          box-shadow: 0 0 40px rgba(0, 245, 255, 0.4);
        }

        .tier-badge {
          position: absolute;
          top: -14px;
          left: 50%;
          transform: translateX(-50%);
          background: #FFD700;
          color: #000;
          padding: 6px 18px;
          border-radius: 14px;
          font-size: 10px;
          font-weight: 700;
          letter-spacing: 0.1em;
        }

        .tier-icon {
          font-size: 56px;
          text-align: center;
          margin-bottom: 16px;
        }

        .tier-name {
          font-family: 'Orbitron', sans-serif;
          font-size: 28px;
          font-weight: 700;
          text-align: center;
          margin-bottom: 8px;
        }

        .tier-tagline {
          text-align: center;
          font-size: 13px;
          color: rgba(255, 255, 255, 0.6);
          margin-bottom: 24px;
        }

        .tier-price {
          text-align: center;
          margin-bottom: 12px;
        }

        .price-amount {
          font-size: 48px;
          font-weight: 900;
          font-family: 'Orbitron', sans-serif;
        }

        .price-period {
          font-size: 16px;
          color: rgba(255, 255, 255, 0.6);
        }

        .tier-savings {
          text-align: center;
          font-size: 14px;
          color: #00FF88;
          font-weight: 600;
          margin-bottom: 24px;
        }

        /* SUBSCRIBE BUTTON */
        .subscribe-btn {
          background: linear-gradient(135deg, #00F5FF 0%, #00D4E0 100%);
          color: #000;
          border: none;
          border-radius: 16px;
          padding: 20px 40px;
          font-weight: 700;
          font-size: 18px;
          font-family: 'Orbitron', sans-serif;
          cursor: pointer;
          width: 100%;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 12px;
          transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
          box-shadow: 0 8px 24px rgba(0, 245, 255, 0.4);
          margin-top: 32px;
        }

        .subscribe-btn:hover {
          transform: translate3d(0, -4px, 0) scale(1.02);
          box-shadow: 0 16px 48px rgba(0, 245, 255, 0.6);
        }

        /* BOTTOM NAV */
        .bottom-nav {
          position: fixed;
          bottom: 0;
          left: 0;
          right: 0;
          background: rgba(0, 18, 25, 0.9);
          backdrop-filter: blur(60px) saturate(180%);
          border-top: 0.5px solid rgba(0, 245, 255, 0.2);
          padding: 12px 0;
          z-index: 1000;
          box-shadow: 0 -8px 32px rgba(0, 0, 0, 0.4);
        }

        .nav-container {
          display: flex;
          justify-content: space-around;
          max-width: 680px;
          margin: 0 auto;
          padding: 0 20px;
        }

        .nav-item {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 6px;
          padding: 10px 16px;
          cursor: pointer;
          border-radius: 14px;
          color: rgba(255, 255, 255, 0.4);
          transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
        }

        .nav-item:active {
          transform: scale(0.92);
        }

        .nav-item.active {
          color: #00F5FF;
          text-shadow: 0 0 20px rgba(0, 245, 255, 0.8);
        }

        .nav-label {
          font-size: 11px;
          font-weight: 600;
          letter-spacing: 0.05em;
        }

        @media (max-width: 768px) {
          .tiers-grid {
            grid-template-columns: 1fr;
          }
          
          .stats-grid {
            grid-template-columns: 1fr;
          }

          .hero-title {
            font-size: 32px;
          }
        }
      \`}</style>

      {/* MARINE SNOW PARTICLES */}
      <div className="particles">
        {[...Array(20)].map((_, i) => (
          <div 
            key={i}
            className="particle"
            style={{
              left: \`\${Math.random() * 100}%\`,
              animationDuration: \`\${Math.random() * 15 + 10}s\`,
              animationDelay: \`\${Math.random() * 5}s\`
            }}
          />
        ))}
      </div>

      {/* MAIN CONTENT */}
      {activeTab === 'home' && (
        <div className="view-container">
          <div className="finn-whale" onClick={() => playSound('bubble')}>
            🐋{dailyStreak >= 7 && '🎩'}
          </div>
          <h1 className="hero-title">Welcome back, Captain</h1>
          <p className="hero-subtitle">Your financial ocean is looking mighty clear today</p>

          {currentTier === 'free' && (
            <div className="premium-banner glass-card" onClick={() => setShowPaywall(true)}>
              <Crown size={32} color="#FFD700" />
              <div style={{flex: 1}}>
                <div style={{fontWeight: 700, fontSize: '18px', color: '#FFD700', marginBottom: '6px'}}>
                  Join The Sovereign Club
                </div>
                <div style={{fontSize: '14px', color: 'rgba(255,255,255,0.7)'}}>
                  Unlock AI Coach, Tax Harvesting & Premium Tools
                </div>
              </div>
              <ChevronRight size={20} color="#FFD700" />
            </div>
          )}

          <div className="stats-grid">
            <div className="stat-card glass-card">
              <div className="stat-icon">🔥</div>
              <div className="stat-value">{dailyStreak}</div>
              <div className="stat-label">Day Streak</div>
            </div>
            <div className="stat-card glass-card">
              <div className="stat-icon">🐚</div>
              <div className="stat-value">{barnaclePoints}</div>
              <div className="stat-label">Barnacle Bucks</div>
            </div>
            <div className="stat-card glass-card">
              <div className="stat-icon">⚡</div>
              <div className="stat-value">{knowledgeXP}</div>
              <div className="stat-label">Knowledge XP</div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'vault' && (
        <div className="view-container">
          <h1 className="hero-title" style={{fontSize: '36px'}}>The Vault</h1>
          <p className="hero-subtitle">Crack the code, earn Barnacle Bucks</p>

          <div className="wordle-grid">
            {[0,1,2,3,4,5].map(rowIndex => (
              <div key={rowIndex} className="wordle-row">
                {[0,1,2,3,4].map(colIndex => {
                  const guess = rowIndex === guesses.length ? currentGuess : guesses[rowIndex];
                  const letter = guess ? guess[colIndex] : '';
                  const colorClass = (guess && rowIndex < guesses.length) ? getTileColor(letter, colIndex, guess) : 'empty';
                  return (
                    <div key={colIndex} className={\`wordle-tile \${colorClass}\`}>
                      {letter}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>

          {!gameWon && guesses.length < 6 && (
            <div className="keyboard">
              {[
                ['Q','W','E','R','T','Y','U','I','O','P'],
                ['A','S','D','F','G','H','J','K','L'],
                ['ENTER','Z','X','C','V','B','N','M','←']
              ].map((row, i) => (
                <div key={i} className="keyboard-row">
                  {row.map(key => (
                    <button
                      key={key}
                      onClick={() => handleKeyPress(key)}
                      className={\`key \${key.length > 1 ? 'key-wide' : ''}\`}
                    >
                      {key}
                    </button>
                  ))}
                </div>
              ))}
            </div>
          )}

          {gameWon && (
            <div className="glass-card bio-glow" style={{textAlign: 'center', padding: '32px'}}>
              <div style={{fontSize: '48px', marginBottom: '16px'}}>🎉</div>
              <h2 style={{fontSize: '24px', fontWeight: 700, marginBottom: '12px'}}>VAULT CRACKED!</h2>
              <p style={{color: '#00F5FF'}}>+50 Barnacle Bucks added to your pod</p>
            </div>
          )}
        </div>
      )}

      {/* PAYWALL MODAL */}
      {showPaywall && (
        <div className="modal-overlay" onClick={() => setShowPaywall(false)}>
          <div className="paywall-modal" onClick={e => e.stopPropagation()}>
            <button className="modal-close" onClick={() => setShowPaywall(false)}>
              <X size={24} />
            </button>

            <div style={{textAlign: 'center', marginBottom: '32px'}}>
              <Crown size={64} color="#FFD700" style={{marginBottom: '20px'}} />
              <h2 className="hero-title" style={{fontSize: '40px', marginBottom: '12px'}}>
                Unlock Your Financial Future
              </h2>
              <p style={{color: 'rgba(255,255,255,0.7)', fontSize: '16px'}}>
                Choose the plan that fits your goals
              </p>
            </div>

            <div className="tiers-grid">
              {Object.entries(subscriptionTiers).map(([key, tier]) => (
                <div 
                  key={key}
                  className={\`tier-card \${selectedTier === key ? 'selected' : ''}\`}
                  onClick={() => {
                    playSound('bubble');
                    setSelectedTier(key);
                  }}
                >
                  {tier.badge && <div className="tier-badge">{tier.badge}</div>}
                  <div className="tier-icon">{tier.icon}</div>
                  <h3 className="tier-name">{tier.name}</h3>
                  <p className="tier-tagline">{tier.tagline}</p>
                  
                  <div className="tier-price">
                    <span className="price-amount">
                      ${billingCycle === 'annual' ? tier.price.annual : tier.price.monthly}
                    </span>
                    <span className="price-period">/{billingCycle === 'annual' ? 'year' : 'month'}</span>
                  </div>
                  
                  {billingCycle === 'annual' && tier.savings && (
                    <div className="tier-savings">Save ${tier.savings}/year</div>
                  )}

                  <div style={{fontSize: '13px', color: 'rgba(255,255,255,0.7)', marginTop: '16px'}}>
                    {tier.features.slice(0, 3).map((f, i) => (
                      <div key={i} style={{marginBottom: '8px'}}>• {f}</div>
                    ))}
                    <div style={{color: '#00F5FF', marginTop: '12px'}}>
                      +{tier.features.length - 3} more features
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <button 
              className="subscribe-btn"
              onClick={() => {
                playSound('success');
                setCurrentTier(selectedTier);
                setShowPaywall(false);
              }}
            >
              <Sparkles size={20} />
              Start 7-Day Free Trial
            </button>

            <p style={{textAlign: 'center', fontSize: '13px', color: 'rgba(255,255,255,0.5)', marginTop: '16px'}}>
              No credit card required • Cancel anytime • 14-day money-back guarantee
            </p>
          </div>
        </div>
      )}

      {/* BOTTOM NAVIGATION */}
      <div className="bottom-nav">
        <div className="nav-container">
          {[
            { id: 'vault', icon: Target, label: 'Vault' },
            { id: 'learn', icon: Award, label: 'Learn' },
            { id: 'home', icon: Home, label: 'Harbor' },
            { id: 'reef', icon: Users, label: 'Reef' },
            { id: 'tides', icon: TrendingUp, label: 'Tides' }
          ].map(({ id, icon: Icon, label }) => (
            <div 
              key={id}
              className={\`nav-item \${activeTab === id ? 'active' : ''}\`}
              onClick={() => {
                playSound('wave');
                setActiveTab(id);
              }}
            >
              <Icon size={22} />
              <span className="nav-label">{label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default LifeVest;
